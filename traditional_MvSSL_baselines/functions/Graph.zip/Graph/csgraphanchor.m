function [A] = csgraphanchor(X,m,k)
V = max(size(X));
for v=1:V
    T = constructAnchorDistance_PKN(X{v}', m,k);
%     T = constructW_PKN(X{v}',k);
%     A{v} = (T+T')/2;
    e = sum(T,1);
    cc = find(e>0);
    A{v} = T(:,cc)*diag(e(cc).^(-1))*T(:,cc)';
end
function [KH,S] = creatKHS(Z,Index)
[num,V] = size(Index);
for v = 1:V
    S{v}.indx = find(Index(:,v)==0)';
    T1 = zeros(num,num);
    T2 = Index(:,v)*Index(:,v)';
    e = sum(Z{v},1);
    A = Z{v}*diag(e.^(-1))*Z{v}';
    T1(T2==1)=A;
    KH(:,:,v)=T1;
end
    
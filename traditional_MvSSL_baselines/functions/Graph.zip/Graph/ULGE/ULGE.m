% X:num*dim
%alpha:regulization num
%numanchor:the real number of anchors is 2^numAnchor
%[1] F. Nie, W. Zhu, and X. Li, "Unsupervised Large Graph Embedding," AAAI2017.
%[2] W. Zhu, F. Nie, and X. Li, "Fast Spectral Clustering with Efficient Large
%Graph Construction," ICASSP2017.
function [W] = ULGE(X,projectionDim,alpha,numAnchor,numNearestAnchor)

X =(double(X));%n*d

num = size(X,1);
dim = size(X,2);

X = X-repmat(mean(X),[num,1]);

[~,locAnchor] = hKM(X',[1:num],numAnchor,1); % here we use BKHK algorithm proposed in [2] to generate anchors.


Z = ConstructA_NP(X',(locAnchor),numNearestAnchor);

sumZ = (sum(Z));
sqrtZ = sumZ.^(-0.5);
regZ = (Z)*(diag(sqrtZ));
[V,S] = eigs(regZ'*regZ,projectionDim+1);
U = regZ*V*inv(S);
F = U(:,2:projectionDim+1);


ddata = (X'*X);
ddata = ddata + alpha*eye(dim);

ddata = max(ddata,ddata');
B = X'*F;
R = chol(ddata);
W = R\(R'\B);


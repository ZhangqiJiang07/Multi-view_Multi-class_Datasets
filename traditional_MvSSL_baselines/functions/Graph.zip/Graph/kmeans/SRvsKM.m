% K-means: min_{G=Ind,H} || G*H - F ||^2
% Spectral rotation: min_{G=Ind,Q'*Q=I} || G*Q - F ||^2
function [Gkm obj_km Gsr obj_sr success] = SRvsKM(F, G)
% F: n*c matrix, the c smallest eigenvectors of (normalized) Laplacian matrix
% G: n*c initial cluster indicator matrix
% Gkm: achieved cluster indicator matrix via K-means
% obj_km: objective value of K-means method
% Gsr: achieved cluster indicator matrix via spectral rotation
% obj_sr: objective value of spectral rotation method
% success: if some clusters are null, success=0, if all clusters are not null, success=1

% Ref:
% Jin Huang, Feiping Nie, Heng Huang.
% Spectral Rotation vs K-means in Spectral Clustering.
% AAAI 2013.


[n,c] = size(F);

izero = find(sum(abs(F),2) <= 10^-10);
F(izero,:) = 1;
F = diag(diag(F*F').^(-1/2)) * F;

Gkm = G;
Gsr = G;
success = 1;
ITER = 20;
obj_km = zeros(ITER,1);
obj_sr = zeros(ITER,1);
for iter = 1:ITER
    % KM discrete
    H = inv(Gkm'*Gkm+eps*eye(c))*Gkm'*F;
    Gkm = calculateR(F, H, 0, 1);
    obj_km(iter) = trace((F-Gkm*H)'*(F-Gkm*H));
    % SR discrete
    [U, d, V] = svd(Gsr'*F);
    Q = U*V';
    Gsr = calculateR(F, Q, 0, 1);
    obj_sr(iter) = trace((F-Gsr*Q)'*(F-Gsr*Q));
    
    succ = sum([Gkm,Gsr]);     
end;

if find(succ==0)
    success = 0; 
end; 


function G1 = calculateR(F, H, a, BQ)
% min_{G=Ind} || G*H - F ||^2 + a*|| G - BQ ||^2

[n,class_num] = size(F);

T = zeros(n,class_num);
for i = 1:class_num
    te = F - ones(n,1)*H(i,:);
    aa = sum(te.*te,2);
    T(:,i) = aa;
end;
T = T - a*2*BQ;
[temp idx] = min(T,[],2);
G1 = zeros(n,class_num);
for i = 1:n
    G1(i,idx(i)) = 1;
end;




    
function z = myconstructAnchor(X, m, k)
%KNNDISTANCE Summary of this function goes here
%   Detailed explanation goes here

% X: each row is a data point
% anchors: each column is a data point
% nRepeat: the execute time to repeat

num=size(X,1);
[inG0]=initialG(m,num);
[G,anchors,~] = NNKM(X,inG0);
O = sum(G,1);
anchors(O==0,:)=[];

D = L2_distance(X',anchors');
D(D<0) = 0;

[~ , idx] = sort(D, 2); % sort each row
z = zeros(num,size(anchors,1));
for i = 1:num
    id = idx(i,1:k);
    di = D(i, idx(i,1:k+1));
    z(i,id) = (di(k+1)-di(1:k))/(k*di(k+1)-sum(di(1:k)));
end

z(isnan(NaN))=1/m;
clear D idx;
T = sum(z,1);
z(:,T==0)=[];
end

function[G0]=initialG(C,num)
I = eye(C);
R = randperm(size(I,1));
g = ceil(num/C);
inG0 = repmat(I(R,:),g,1);
G0 = inG0(1:num,:);
end

function [G,F,obj] = NNKM(X,inG0)

% parameter settings
maxIter = 30;
thresh = 1e-6;
[num,C] = size(inG0);
% inti common indicator G
G = inG0;
% loop
obj = zeros(maxIter, 1);
for iter = 1: maxIter
    %     fprintf('processing iteration %d...\n', iter);

    % update F
    A = G'*G;
    B = G'*X;
    F = (A+10^(-12)*eye(size(A,1)))\B;

    % update G
    H = zeros(num,C);
    G = zeros(num,C);
    P = zeros(num,1);
    for c = 1:C
        H(:,c) = sum((X-repmat(F(c,:),num,1)).^2,2);
    end
    for i = 1:num
        [P(i),yi] = min(H(i,:));
        G(i,yi)=1;
    end
    % calculate the obj
    obj(iter) = sum(P)+10^(-12)*norm(F,'fro')^2;
    if(iter > 2)
        diff = (obj(iter-1) - obj(iter))/abs(obj(iter));
        if(diff < thresh)
            break;
        end
    end
end
end
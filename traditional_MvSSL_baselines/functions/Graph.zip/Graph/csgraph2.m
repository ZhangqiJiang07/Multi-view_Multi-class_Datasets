function [A] = csgraph2(Z)
V = max(size(Z));
for v=1:V
    T = Z{v}; 
%     A{v} = (T+T')/2;
    e = sum(T,1);
    cc = find(e>0);
    A{v} = T(:,cc)*diag(e(cc).^(-1))*T(:,cc)';
end
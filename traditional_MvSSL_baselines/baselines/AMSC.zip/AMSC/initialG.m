function[G]=initialG(C,num)
I = eye(C);   
R = randperm(size(I,1)); 
g = ceil(num/C);
inG0 = repmat(I(R,:),g,1); 
G0 = inG0(1:num,:);
[~,G] = max(G0,[],2);
end
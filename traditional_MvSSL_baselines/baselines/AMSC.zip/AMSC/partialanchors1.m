function [Z]= partialanchors1(X,index,m,k,Label)
      V = max(size(X));
% % % % 
      for v=1:V
            t = find(index(:,v)==1);
% % % % % % % %      Z{v} = myconstructAnchor(X{v}(t,:), m(v), k);
            
            T = X{v}(t,:)';
% % %     kk=length(size(T));
% % 
            if m(v) > size(T, 2)
                  m(v) = size(T, 2);
            end
            Z{v} = constructAnchorDistance_PKN( T, m(v),k);
%   
%      beta=0.5;
%     m=30;
%            [Z,obj]=  algo_AZ(X,Label,m,beta);
%             for i=1:numel(Z)
%              
% %             Z{i}(isnan(Z{i})==1)=0;
% %        
% %              if sum(sum(isnan(Z{i})))>0
% %      Z{i}(isnan(Z{i})==1)=1;
% %   
% % %             end
%      Z{i}(isnan( Z{i})) = 0;
%    T = sum(Z{i}, 1);
%    Z{i}(:,find(T==0))=[];
% 
%    Z{i} = Z{i}';
%     s0=sum(Z{i},2);%length(find(isnan(s0)))
%     Z{i}=Z{i}./repmat(s0,1,size(Z{i},2));
%             end

%     save k k;
% save  Z Z
      end
end
function [Ypre,Out ] = pmss_inv(Ll, Index, Z ,inPara)
% Ll: labeled instances indicator of gnd
% Index: indicator of instances in each view, nxV
% Z: cell, 
% Out: struct of model
% Ypre: predicted lables of unlabeled data
maxIter = 60;
thresh = 1e-4;
p = inPara.p;  
r = inPara.r;
for i=1:length(Z)
   Z{i}(isnan(Z{i})) = 0;
end
View = max(size(Z));
n = size(Index,1);
nl = size(Ll,1);
nu = n-nl;
nc = max(Ll)-min(Ll)+1;
%% construct graphs
for v=1:View
   %% Initilization
   %% alpha
   alpha(v) = 1/View;
   V_ind{v} = find(Index(:,v)==1);
   Vl_ind{v} = V_ind{v}(V_ind{v}<=nl);
   Vu_ind{v} = V_ind{v}(V_ind{v}>nl);
   F{v} = zeros(n,nc);
   H{v} = zeros(n,nc);
   nv(v) = sum(Index(:,v));
   e{v} = sum(Z{v},1);
   te = find(e{v}>0.01);
   A{v} = Z{v}(:,te)*diag(e{v}(te).^(-1))*Z{v}(:,te)';
   D{v} = sum(Z{v},2);
   L{v} = diag(D{v})-A{v};
end
Y = zeros(n,nc);
for i = 1:nl
    Y(i,Ll(i)) = 1;
end
Y((i+1):end,:) = 1/nc;
YG = Y.^(r);
U = sum(YG,2);

for iter = 1:maxIter
    fprintf('AMSC iteration %d...\n', iter);
   %% given GC, update F{v}
          
     for v = 1:View
        AA = diag(U(V_ind{v}))+2*L{v};
        BB = YG(V_ind{v},:);
        F{v}(V_ind{v},:) = AA\BB;     
    end
    %% Update label matrix Y
    Yut = zeros(n,nc);
    for v = 1:View
        H{v}(Vl_ind{v},:) = (F{v}(Vl_ind{v},:)-Y(Vl_ind{v},:)).^2;
        Tu1 = (F{v}(Vu_ind{v},:)-ones(max(size(Vu_ind{v})),nc)).^2; 
        Tu2 = F{v}(Vu_ind{v},:).^2;
        Tu2s = sum(Tu2,2);
        for c = 1:nc
            H{v}(Vu_ind{v},c) = Tu2s-Tu2(:,c)+Tu1(:,c);
            Yut(Vu_ind{v},c) = Yut(Vu_ind{v},c)+alpha(v)*H{v}(Vu_ind{v},c);  
        end
    end
    if (r==1)
        Yu = zeros(nu,nc);
        [~,YII]=min(Yut((nl+1):end,:)');
        for i = 1:nu
            Yu(i,YII(i)) = 1;
        end
    else
        Yut = (r.*Yut((nl+1):end,:)).^(1/(1-r));
        s0=sum(Yut,2);%length(find(isnan(s0)))
        Yu=Yut./repmat(s0,1,nc);
        Yu(isnan(Yu)==1)=1;
    end
    Y((nl+1):end,:) = Yu;
    YG((nl+1):end,:) = Yu.^(r);
    U((nl+1):end,:) = sum(YG((nl+1):end,:),2);
    
    %% update alpha
    for v = 1:View
        dist = L2_distance(F{v}(V_ind{v},:)',F{v}(V_ind{v},:)');
        if size (A{v})==size(dist)
        g(v) = sum(sum(A{v}.*dist));
        g(v) = g(v)+sum(sum(YG(Vu_ind{v},:).*H{v}(Vu_ind{v},:)));
        g(v) = g(v)/nv(v);
        alpha(v) = g(v).^(p-1);
        end
    end  
    
   %% calculate the objective
    obj(iter) = sum(g.^p);
    if(iter > 2)
        obj_diff = (obj(iter-1) - obj(iter))/obj(iter-1);
        if(obj_diff < thresh)
            break;
        end
    end
end
outObj = obj(2:iter);
[~,Ypre] = max(Yu,[],2);
Out.obj = outObj;
Out.Alpha = alpha;
Out.Yu = Yu;

end
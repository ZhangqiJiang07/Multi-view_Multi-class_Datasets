function [Ypred, Out] = AMUSE(Xl,Xu,Yl,lambda,cell_A)
%%%%%%% Multiview Semi-Supervised Learning Model for Image Classification (TKDE'20)
%   Params:
%       Xl/Xu: cell,
%             Xl{v}/Xu{v} is the feature matrix of v-th view, numSamp x numFea
%       Yl: matrix,
%             The {0,1} one-hot encoded label matrix, numLabeledSamp x numClass
%       cell_A: cell, (optional)
%             cell_A{v} is the affinity matrix of v-th view, numSamp x numSamp

%% Initialization
maxIter = 30;
epsilon = 1e-3;
num_views = length(Xl);
num_samples = size(Xl{1}, 1) + size(Xu{1}, 1);
num_class = size(Yl, 2);
num_labeled = size(Yl, 1);

% init main matrices
alpha = ones(num_views, 1) ./ num_views;
F = zeros(num_samples, num_class);
F(1:num_labeled,:) = Yl;
S = zeros(num_samples, num_samples);
for v = 1:num_views
    S = S + cell_A{v};
end
S = S ./ num_views;

weighted_sum_A = zeros(num_samples, num_samples);
for v = 1:num_views
    weighted_sum_A = weighted_sum_A + alpha(v) * cell_A{v};
end

% record alpha for ablation
alpha_matrix = zeros(maxIter, num_views);
alpha_matrix(1, 1:num_views) = alpha;
% record alpha for ablation


%% MAIN LOOP
flag = 1;
iter = 1;
obj = [];
while flag
    % compute Laplacian matrix
    Ss = (S + S') / 2;
    Ds = diag(sum(Ss,2));
    Ls = Ds - Ss;

    %%%%%%%%%%%%%  Update F
    Luu = Ls(num_labeled+1:end,num_labeled+1:end);
    Lul = Ls(num_labeled+1:end,1:num_labeled);
    F(num_labeled+1:end,:) = - Luu^(-1) * Lul * Yl;

    %%%%%%%%%%%%%  Update S
    FF_dist = L2_distance_1(F',F'); % numSamp x numSamp
    
    S = zeros(num_samples, num_samples);
    for i = 1:num_samples
        t_i = weighted_sum_A(i,:) - FF_dist(i,:)./(4*lambda);
        S(i,:) = EProjSimplex_new(t_i);
    end

    %%%%%%%%%%%%% Update alpha
    flatten_A = zeros(num_samples*num_samples, num_views);
    for v = 1:num_views
        flatten_A(:, v) = cell_A{v}(:);
    end
    P = flatten_A' * flatten_A;
    Q = 2 * flatten_A' * (S(:));
    alpha = SimplexQP(P, Q, 200, 1.1, 0, alpha);


    %%%%%%%%%%%%% Check convergence
    weighted_sum_A = zeros(num_samples, num_samples);
    for v = 1:num_views
        weighted_sum_A = weighted_sum_A + alpha(v) * cell_A{v};
    end
    obj(iter) = norm(S - weighted_sum_A, 'fro')^2 + trace(F'*Ls*F)/lambda;

    % if iter > 2
    %     if abs((obj(iter-1)-obj(iter)) / obj(iter-1)) < epsilon || iter >= maxIter;
    %         flag = 0;
    %     end
    % end
    iter = iter + 1;

    % record alpha for ablation
    alpha_matrix(iter, 1:num_views) = alpha;
    if iter >= maxIter
        flag = 0;
    end
    % record alpha for ablation
end

% Final prediction
Fu = F(num_labeled+1:end, :);
[~, Ypred] = max(Fu, [], 2);
Out.Fu = Fu;
Out.alpha = alpha;
Out.alpha_matrix = alpha_matrix;

end
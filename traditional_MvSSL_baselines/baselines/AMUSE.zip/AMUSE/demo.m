clear
clc
warning off;

path = './';
addpath(genpath(path));

load('/root/jzq/code_UAMSC/datasets/Caltech101_20.mat')
Y = gnd;

num_views = length(X);
name='norm';
for v = 1:num_views
     X{v} = preprocess(X{v}, name);
end

k = 7;
lambda = 1e1;
test_time = 1;
missing_rate = 0;
labeled_rate = 0.05;

for test_i = 1:test_time
    %% Generate partial data
    [M, temp_index] = partialData(X, missing_rate, 2);
    Y = reshape(Y, [], 1); % make sure Y is a column vector
    [MX, Ll, Lu, ~] = labelData(M, Y, temp_index, labeled_rate);
    num_labeled = size(Ll, 1);

    cell_A = cell(num_views, 1);
    for v = 1:num_views
        Xl{v} = MX{v}(1:num_labeled, :);
        Xu{v} = MX{v}(num_labeled+1:end, :);
        cell_A{v} = constructW_PKN(MX{v}', k, 0);
    end

    Yl = TransLabelR(Ll);
    [Ypred, Out] = AMUSE(Xl, Xu, Yl, lambda, cell_A);

    ACC = mean(Ypred == Lu);
    disp(['ACC: ' num2str(ACC)]);
end


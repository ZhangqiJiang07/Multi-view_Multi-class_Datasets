function [ssn,objl] = calculatess(f,grad_f,obj1,ss,alpha,beta,H,S,TT,lam2,n,ln)
Maxiter = 1000;
obj2 = norm(grad_f,'fro')^2;
for i=1:Maxiter
    objr = obj1-alpha*ss*obj2;
    fn = f-ss*grad_f;
    [loss1,loss2] = SLIM_obj(H,fn,S,TT,lam2,n);
    objl = loss1+loss2;
    if objl<=objr
        ssn = ss;
        break;
    else
        ss = ss*beta;
    end
end
end
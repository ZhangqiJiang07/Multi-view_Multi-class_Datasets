function [loss1,loss2]=SLIM_obj(H,f,S,TT,lam2,n)
loss1 = trace(f'*H*f);
num = size(f,1);
V = max(size(S));
loss2 = 0;
S_a = f*f';
for v=1:V
    ST = zeros(num,num);
    ST(TT{v}==1) = S_a(TT{v}==1);
    loss2=loss2+lam2/(2*n(v))*norm((ST-S{v}),'fro');
end
end
function [Ypre,f,obj] = SLIM(X,label,Index,options)
lam1 = options.lam1;
lam2 = options.lam2;
stopc = options.stop;
View = max(size(X));
nC = max(label)-min(label)+1;
num = size(X{1},1);
ln = max(size(label));
H = zeros(num,num);
fu = ones(num-ln,nC)/nC;
fl = zeros(ln,nC);
alpha = 0.3;
beta = 0.8;
maxIter = 5;
ss = 1;
for i = 1:ln
    fl(i,label(i))=1;
end
f = [fl;fu];
for v = 1:View
    X{v}(isnan(X{v})==1)=0;
    %% Calculate H
    TT{v} = Index(:,v)*Index(:,v)';
    O{v} = diag(Index(:,v));
    n(v) = sum(Index(:,v));
    dim(v) = size(X{v},2);
    C{v} = O{v}-TT{v}/n(v);
    B{v} = X{v}'*C{v}';
    invA{v} = B{v}*B{v}'+n(v)*lam1*eye(dim(v));
    AmB{v} = invA{v}\B{v};
    H = H+C{v}'*AmB{v}'*(lam1/2*AmB{v}*C{v}+0.5/n(v)*B{v}*B{v}'*AmB{v}*C{v}-1/n(v)*B{v}*C{v})+0.5/n(v)*C{v}'*C{v};
    %% Construct S{v}
    tempX{v} = zeros(num,dim(v));
    S{v} = zeros(num,num);
    for i = 1:num
        if Index(i,v)==1
            tt = norm(X{v}(i,:)); 
%             tt = 1;
            if tt>0&&isnan(tt)==0
            tempX{v}(i,:) = X{v}(i,:)/tt;
            else
            tempX{v}(i,:) = ones(1,dim(v))/sqrt(dim(v));
            end
        end
    end
    S{v} = tempX{v}*tempX{v}';
end
for iter = 1:maxIter
    fprintf('SLIM iteration %d...\n', iter);
    grad_1 = H * f;
    S_a = f*f';
    grad_2 = zeros(num,nC);
    for v = 1:View
        ST = zeros(num,num);
        ST(TT{v}==1) = S_a(TT{v}==1);
        pro{v} = ST-S{v};
        normv(v) = norm(pro{v},'fro');
        if normv(v) == 0
            pro{v} = 0;
        else
            pro{v} = pro{v}/normv(v);
        end
        grad_2 = grad_2 + pro{v}*f/n(v);
    end
    grad_f = grad_1+grad_2*lam2;
    if iter == 1
        [loss1(iter),loss2(iter)] = SLIM_obj(H,f,S,TT,lam2,n);
        obj(iter) = loss1(iter)+loss2(iter);
    end
    [ssn]= calculatess(f,grad_f,obj(iter),ss,alpha,beta,H,S,TT,lam2,n);
    fn = f-ssn*grad_f;
    ss = ssn; 
    tmp_0 = zeros(size(fn));
	tmp_1 = ones(size(fn));

	fn(find(fn<=0)) = tmp_0(find(fn<=0));
	fn(find(fn>=1)) = tmp_1(find(fn>=1));
    fn(1:ln,:)=f(1:ln,:);
    [loss1(iter+1),loss2(iter+1)] = SLIM_obj(H,fn,S,TT,lam2,n);
    obj(iter+1) = loss1(iter+1)+loss2(iter+1);
    if iter>1 && (abs(obj(iter+1)-obj(iter))/obj(iter+1)<stopc)
		fprintf('Object value converge to %.4f at iteration %d before the max OUTer Iteration reached\n', obj(iter), iter);
		break;
    end
    f = fn;
end
[~,Ypre] = max(f(ln+1:end,:),[],2);
f = f(ln+1:end,:);




end




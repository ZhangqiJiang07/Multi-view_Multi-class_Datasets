   uuuu=X;
kk=gnd;
[ACC,Fscore]=mainprocedure1(uuuu,kk);


function [ACC,Fscore] = mainprocedure1(X,Label)
g=[];
ff=[];
kall = 5;
Ntime = 10;
tr = 0;
C = max(Label)-min(Label)+1;
l = 0.1;
for pratio = 0:0.1:0.5   %%%����partialdata��labeldata
    tr = tr+1;
    for ti = 1:1:Ntime
        [M1,Index1] = partialdata(X,pratio);
        [M, Ll, Lu, Index] = labeldata(M1,Label,Index1,l);
        nu = size(Lu,1);
        v_idx=[];
        for c = 1:C
            cc = find(Lu==c);
            ncl = ceil(max(size(cc))/1);
            dd = randperm(max(size(cc)),ncl);
            v_idx = [v_idx;cc(dd)];
        end
      
 
        %% My Method
        T = 0;
        b = 0;
        %% ��һ��
        for v=1:max(size(M))
            m(v) = 200;

        end

         Z = partialanchors1(M,Index,m,kall,Label);



        %% SLIM
        T = 0;
        lam1 = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
        %         lam1 = 1e3;
        lam2 = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
        %         lam2 = 1e3;
        for i = 1:2:9
            %         for i = 1:9
            %             for j = 1
            for j = 1:2:9
                options.lam1 = lam1(i);
                options.lam2 = lam2(j);
                options.stop = 1e-4;
                [Yslim,f,obj] = SLIM(M,Ll,Index,options);
                [AC,Fs] = accfscore(Yslim(v_idx),Lu(v_idx))
                                 g=[g;AC];
                  ff=[ff;Fs];
                MA(i,j) = AC;
                if AC+Fs>=T
                    [AC1,Fs1] = accfscore(Yslim,Lu);
                    blam1 = lam1(i);
                    blam2 = lam2(j);
                    ACCslim(ti,tr) = AC1;
                    Fscoreslim(ti,tr) = Fs1;
                    T = AC+Fs;
                end
            end
        end
         ACC = ACCslim;
           Fscore = Fscoreslim;


 


% ACC.slim = ACCslim;
%  

% % Fscore.slim = Fscoreslim;
save g g

save  ff ff

     end
end
end
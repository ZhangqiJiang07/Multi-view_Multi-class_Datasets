function q=optimize_q(X,W,F,n)
    q = zeros(n,1);
%     b_w=ones(n,1);
    temp3=0;
    for i = 1:n
        loss_i = (X(i,:)*W-F(i,:));
        temp2(i) = sqrt(loss_i*loss_i');
        temp3 = temp3+temp2(i);
    end
    for i = 1:n
        q(i) = n*(temp2(i)+eps)/temp3;
    end
%    q = 1./(nl*q_i);% 
%      b_w(1:nl)=nl;
%      b_w(nl+1:n)=n*(n/nl-1);
%      q = 1./(q_i);
     clear temp2 b_w;
function [x, val] = SimplexQP(A, b, Mu, rho, pic, x)
% solve:
% min     x'Ax - b'x
% s.t.    x'1 = 1, x >= 0
% paras:
% Mu    Mu > 0
% rho   1 < rho < 2
%

NITER = 100;
THRESHOLD = 1e-4;

val = 0;

if nargin < 6
    x = zeros(size(b));
end
v = ones(size(x));

eta = ones(size(x));
cnt = 0;

if pic
    rec = [];
end

for iter = 1:NITER
    x = EProjSimplex_new(v - 1/Mu*(eta + A*v-b));
    v = x + 1/Mu*(eta - A'*x);
    eta = eta + Mu*(x - v);
    Mu = rho*Mu;
    
    val_old = val;
    val = x'*A*x - b'*x;
    
    if pic
        rec = [rec val];
    end
    
    if abs(val - val_old) < THRESHOLD
        if cnt >= 5
            break;
        else
            cnt = cnt + 1;
        end
    else
        cnt = 0;
    end
end

%  fprintf('Using SimplexQP, relax gap: %.5f, iter: %d, mu: %.3f\n', norm(x-v), iter, Mu);
if pic
    plot(rec);
end

end
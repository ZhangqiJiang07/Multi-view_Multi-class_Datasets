%%%% demo_MVAG
clear
addpath('data')
data_name='MSRC-v1'; % 
load(data_name);
viewNum = length(X);
maxIter = 50;
name='norm';
Cl=10000;
Cu=0.0001;%����С
for v = 1:viewNum
     X{v} = preprocess(X{v},name);
end
% viewNum=1;
Y=TransLabelR(Y);
%% data can be pre-processed by centerization or normalization if necessary
train_ratio=1;
times=20;
labeled_ratio=0.2;
[train_index,test_index] = split_data(Y,train_ratio,times);
train_num=size(train_index,2);
[labeled_index,unlabeled_index] = labeled_unlabeled(Y,train_index,labeled_ratio); %% �ĳ�ƽ�������ѡȡ����
%%%%     lambda: the trade-off parameters for lambda*sum_{v=1}^m||W_v||_F^2
%%%%     beta��the trade-off parameters for graph learning
%%%%     mu��the trade-off parameters for reconstruction and distance
%%%%     gamma��the trade-off parameters for prejection learning

lambda = [1,10];
gamma=[0.1];
beta=[0.1,10,100];
for p1=1:length(lambda)
     for p2=1:length(gamma)
        for p3=1:length(beta)
                 for j=1:times
                    for v = 1:viewNum
                         Xl{v}=X{v}(labeled_index(j,:),:);
                         Xu{v} =X{v}(unlabeled_index(j,:),:);
                         Xt{v}=X{v}(test_index(j,:),:);
                    end
                     Yl = Y(labeled_index(j,:),:);
                     [W,F,ypre_un] =CFSMC(Xl,Xu,Yl,lambda(p1),gamma(p2),beta(p3),Cl,Cu);
                     [~,gnd] = max(Y,[],2);
                     gnd_un = gnd(unlabeled_index(j,:));
                     acc_un(j) = mean(gnd_un == ypre_un);
                     Ft = zeros(size(Xt{1},1),size(Y,2));
                     en = ones(size(Xt{1},1),1);
                     flag = 0;
                     dim = zeros(viewNum, 1);
                     for v = 1:viewNum
                        dim(v)  = size(Xt{v},2)+1;       
                        Ft = Ft +[Xt{v} en]*W((flag+1):(flag + dim(v)),:);
                        flag = flag + dim(v);
                     end
                    [~,yte_pre] = max(Ft,[],2);  
                    [~,gnd_te] = max(Y(test_index(j,:),:),[],2);
                    acc_te(j) = mean(gnd_te== yte_pre);
                end
%                 [v1,~]=sort(acc,'descend');
                accuracy_un(p1,p2,p3)=mean(acc_un);
                accuracy_te(p1,p2,p3)=mean(acc_te);
         end
     end
end



max_x1=max(accuracy_un(:));
s1=size(accuracy_un);
Lax1=find(accuracy_un>=max_x1);
[m1,n1,k1]=ind2sub(s1,Lax1);
sprintf('unlabeled: lambda = %.4f,gamma= %.4f,beta=%.4f',lambda(m1),gamma(n1),beta(k1))

max_x2=max(accuracy_te(:));
s2=size(accuracy_te);
Lax2=find(accuracy_te>=max_x2);
[m2,n2,k2,pp2]=ind2sub(s2,Lax2);
sprintf('test: lambda = %.4f,gamma= %.4f,beta=%.4f',lambda(m2),gamma(n2),beta(k2))


accuracy_un
accuracy_te
%% make prediction on unseen data if exists 
 
function [F,G]=optimize_fast(XX_train,Y,S,u,q,M,A,beta)

[n,~] = size(XX_train);

% M=XX_train'.*repmat(q',dim,1); %% XQ
% A=(M*XX_train+lambda*diag(1./alpha.^2))+eps; %% d*d


U = spdiags(u,0,n,n);

V_inv = spdiags((u+q+beta.* ones(n,1)).^-1, 0, n, n);

C = [M' S];

Sigma = diag(sum(S));
M_inv = blkdiag(A,Sigma./beta);
VUY = V_inv * U * Y;

F = VUY + V_inv * (C * (full(M_inv-C' * V_inv * C) \ (C' * VUY)));
G = Sigma\(S'* F);
[~,ypre] = max(G,[],2);
Ypre = zeros(size(G,1),size(G,2));
 for i = 1:size(G,2)
    Ypre(ypre == i,i) = 1;
 end
G = Ypre;
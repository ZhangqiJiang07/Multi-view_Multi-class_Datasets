function [av_matrix,WW,F,ypre] = CFSMC(Xl,Xu,Yl,lambda,gamma,beta,Cl,Cu)
if ~exist('maxIter','var')
    maxIter = 30;
end
viewNum = length(Xl);
[nlSmp,nClass] = size(Yl);
nuSmp = size(Xu{1},1);
nSmp = nlSmp + nuSmp;
k=7;
%% initialization
W = cell(viewNum,1); b = W;  
%  initialize the model by using the labeled samples
for v = 1:viewNum
    [W{v}, b{v}] = least_squares_regression(Xl{v},Yl,lambda);
end
X = cell(viewNum,1);
G=X;
P=X;
p=X;
en = ones(nSmp,1);
flag = 0;
XX_train = []; 
WW=XX_train;
% bb=WW_old;
dim = zeros(viewNum, 1);
av= ones(viewNum,1)/viewNum;  %% initialize the view weight
av_matrix = zeros(maxIter, viewNum);
av_matrix(1, 1:viewNum) = av;
Alpha=[];
% Alpha=alpha;
%% b is absorbed into W
for v = 1:viewNum
    X{v} = [Xl{v}; Xu{v}];
    G{v}=initialize_graph(X{v}',k, 0);
    dim(v)  = size(X{v},2)+1;
    XX_train(:,(flag+1):(flag + dim(v))) = [X{v} en];%n*(d+1)
    WW((flag+1):(flag + dim(v)),:) = [W{v}; b{v}'];%(d+1)*c
    Alpha((flag+1):(flag + dim(v)),:) = repmat(av(v),dim(v),1);%the view weight
    flag = flag + dim(v);
end
iter = 1;
Y = zeros(nSmp,nClass);F=Y;
Y(1:nlSmp,:) = Yl;
u=zeros(nSmp,1);
u(1:nlSmp)=Cl;
u(nlSmp+1:nSmp)=Cu;
% initialize q
q=ones(nSmp,1);
%% initialize affinity graph S
S = zeros(nSmp);
for v = 1:viewNum
	S = S +G{v};
end
S = S ./viewNum;
Ss = (S + S') / 2;
L = diag(sum(Ss))-Ss;
obj=zeros(maxIter,1);
    while iter < maxIter

        %% update F faster
              if size(XX_train,2)<nSmp %%d < n 
                 M=XX_train'.*repmat(q',size(XX_train,2),1); %% XQ
                 A=(M*XX_train+lambda*diag(1./Alpha.^2))+eps; %% d*d
                 B=(A\M);%d^3 
              else %% d>n
                 M= repmat(Alpha'.^2,size(XX_train,1),1)'.*XX_train'; %% AX
                 A=XX_train*M+lambda*diag(1./q)+eps;
                 B=M/A;
              end
            % C=(eye(nSmp)-B'*XX_train').*repmat(q',nSmp,1)';
             C=repmat(q',nSmp,1)'.*(eye(nSmp)-B'*XX_train');
             F =(diag(u)+beta*L+C)\(repmat(u',size(Y,2),1)'.*Y);


             Fu=F(nlSmp+1:nSmp,:);
             [~,ypre] = max(Fu,[],2);
             Ypre = zeros(nuSmp,nClass);
             for i = 1:nClass
                Ypre(ypre == i,i) = 1;
             end
             F(1:nlSmp,:) = Yl;
             F(nlSmp+1:nSmp,:) = Ypre;
%       F = F * diag(sum(F).^-1);
       %% update WW faster

                 WW=B*F;% Faster�����׳�������ֵ
                 clear B
                % WW_dv = pinv(A)) * (XX_train'*F);
           %% update alpha_v Using QP
       
                w= repmat(1./Alpha',size(WW,2),1)'.*WW; 
                flag=0;
                BigA = zeros(nSmp*nClass, viewNum);
                BigB=  zeros(nSmp*nSmp, viewNum);
                for v = 1:viewNum
                      p{v}=XX_train(:,(flag+1):(flag + dim(v)))*w((flag+1):(flag + dim(v)),:);
                      P{v}= repmat(q'.^0.5,size(p{v},2),1)'.* p{v};
                      BigA(:, v) =  P{v}(:);
                      BigB(:, v) = G{v}(:);
                      flag = flag + dim(v);
                end
                f= repmat(q'.^0.5,size(F,2),1)'.*F;
                PP = BigA'*BigA+gamma*(BigB'*BigB);           
                QQ = 2*(BigA'*(f(:))+gamma*BigB'*(S(:)));
                clear f p P w BigA BigB 
                av = SimplexQP(PP, QQ, 100, 1.1, 0, av ); %
                av_matrix(iter+1, 1:viewNum) = av;
    %           ���׳���һЩav�ķ���Ϊ0����ɳ��򱨴������Բ��� rho  ��1 < rho < 2��������һЩ�������������
                 flag=0;          
                 for v = 1:viewNum
                        Alpha((flag+1):(flag + dim(v)),:) = repmat(av(v),dim(v),1);%the view weight
                        flag = flag + dim(v);
                 end

       %% update S 
              distF = L2_distance_1(F',F');
              S = zeros(nSmp);
             for i=1:nSmp
                a0 = zeros(1, nSmp);
                for idx = 1:viewNum
                    a0 = a0 + av(idx)*G{idx}(i, :);
                end
                 in    = 1:nSmp;
                 in(i) = []; %ʵ��s_ii=0
                 S(i,in) = EProjSimplex_new(a0(in)-beta*distF(i,in)/4*gamma );
%                 S(i,:) = EProjSimplex_new(a0-beta*distF(i,:)/4*gamma );
             end
             Ss = (S + S') / 2;
    %         sqrtD = diag(sum(Ss).^-.5);
    %         L = eye(nSmp) - sqrtD * Ss *sqrtD; %% ��һ����ͼ������˹
             L = diag(sum(Ss))-Ss;

             B1=trace((F-Y)'.*repmat(u',size(Y,2),1)*(F-Y));
             B2=beta*trace(F'*L*F);
             B3=trace((XX_train*WW-F)'*diag(q)*(XX_train*WW-F));
             Aa=zeros(nSmp);
             for j=1:viewNum
                 Aa=av(j)*G{j};
             end
             B4=gamma*norm(S-Aa, 'fro' )^2;
             B5=lambda*trace(WW'.* repmat(1./(Alpha'.^2),size(WW,2),1)*WW);        
             obj(iter)=B1+B2+B3+B4+B5;
             if iter>2
                if abs((obj(iter-1)-obj(iter))/obj(iter-1))<0.0001
                 break
                end
             end
             iter = iter + 1;

     end

Fu=F(nlSmp+1:nSmp,:);
[~,ypre] = max(Fu,[],2);
end


function [W, b] = least_squares_regression(X,  Y,  lambda)

% X:                                     each row is a data point
% Y:                                     each row is an target data point: such as  [0, 1, 0, ..., 0]'
% gamma:                                 a positive scalar

[N, dim] = size (X);
% [~, dim_reduced] = size(Y);

% first step,  remove the mean!
XMean = mean(X);                                       
XX = X - repmat(XMean, N, 1);                    

if dim < N
    
    % W = pinv( XX * XX' + gamma * eye(dim)) * (XX * Y');
    %  Note that the above sentence can be repalced by the following sentences. So, it is more fast.
    t0 =  XX' * XX + lambda * eye(dim);
    W = t0 \ (XX' * Y);   
    b = Y -  X*W;    
    b = mean(b)';       
    
else
    t0 = XX * XX' + lambda * eye(N);
    W = XX' * (t0 \ Y);
    b = Y -  X*W;     
    b = mean(b)';       
    
end
end


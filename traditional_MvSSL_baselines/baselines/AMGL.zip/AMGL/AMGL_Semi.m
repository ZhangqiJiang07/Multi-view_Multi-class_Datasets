%% Auto-weighted Multi-view Graph Learning (AMGL) for semi-supervised classification
% Solve the problem;
%                   min_{f_i = y_i, 1 <= i <= l} sum_v sqrt(trance(F'*L_v*F))
function [Ypre, F_u] = AMGL_Semi(A,Ll)
% X: cell array, 1 by view_num, each array is d_v by N
% some default parameters: thresh = 10^-8; maxIter = 100;  

view_num = max(size(A));
N = size(A{1},1);
LN = size(Ll,1);
l = size(Ll, 1);
YL = zeros(l,max(Ll));
for i=1:l
    YL(i,Ll(i))=1;
end 
thresh = 1e-7;

% Construct the affinity matrix for each view data
for v = 1:view_num
     %% fea_v is a d_i by n matrix
    A{v} = (A{v}+A{v}')/2;
    d = sum(A{v});
    D = diag(d);
    L{v} = D-A{v};
    %%
%     [~,A{v}] = selftuning(X{v}, k);
%     D{v} = diag(sum(A{v}));
%     L{v} = D{v} - A{v};
end  

% Iterately solve the target problem
maxIter = 15;
alpha = 1/view_num*ones(1,view_num);

for iter = 1:maxIter
    fprintf('AMGL iteration %d...\n', iter);
    % Given alpha, update F_u
    L_sum = zeros(N);
    for v = 1:view_num
        L_sum = L_sum+alpha(v).*L{v};
    end
    L_ul = L_sum((LN+1):N,1:LN);
    L_uu = L_sum((LN+1):N,(LN+1):N);
    F_u = -0.5*inv(L_uu)*L_ul*YL;
    % Given F_u, update alpha
    F = [YL;F_u];
    for v = 1:view_num
          alpha(v) = 0.5/sqrt(trace(F'*L{v}*F));
    end
    % Calculate objective value
    obj = 0;
    for v = 1:view_num
          obj = obj+sqrt(trace(F'*L{v}*F));
    end
    Obj(iter) = obj;
    if iter>2
        Obj_diff = ( Obj(iter-1)-Obj(iter) )/Obj(iter-1);
        if Obj_diff < thresh
            break;
        end
    end
end
[~,Ypre] = max(F_u,[],2);





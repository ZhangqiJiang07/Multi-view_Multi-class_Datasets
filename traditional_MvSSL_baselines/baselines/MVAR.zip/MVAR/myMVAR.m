function [Y_pred, Out] = myMVAR(X, Ll, c, lambda, mu, r)

viewNum = length(X);
nSmp = size(X{1},1);
labelLen = length(Ll);
s = ones(nSmp,1);
s(1:labelLen) = 10^mu;

for v = 1:viewNum
    Xl{v} = X{v}(1:labelLen,:);
    Xu{v} = X{v}(labelLen+1:end,:);
end

Y_l = zeros(labelLen, c);
for i=1:labelLen
    Y_l(i, Ll(i))=1;
end


[~,~,~,Y_pred, Fu] = MVAR(Xl,Xu,Y_l,lambda, s, r, 10);
Out.Fu = Fu;


end
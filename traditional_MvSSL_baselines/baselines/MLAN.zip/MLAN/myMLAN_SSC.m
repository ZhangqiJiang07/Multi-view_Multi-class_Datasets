function [Ypre,obj] = myMLAN_SSC(X,Ll,k)
% X:                cell array, 1 by view_num, each array is num by d_v
% k:                number of adaptive neighbours
% Y_L:              labeled matrix

v = max(size(X));
num = size(X{1},1);
LN = size(Ll,1);
c = max(Ll);
YL = zeros(LN,c);
for i=1:LN
    YL(i,Ll(i))=1;
end 
c = size(YL,2);
lambda = randperm(30,1);
NITER = 30;
thresh = 10^-4;

%% =====================   Normalization =====================
for i = 1 :v
    for  j = 1:num
        X{i}(j,:) = ( X{i}(j,:) - mean( X{i}(j,:) ) ) / std( X{i}(j,:) ) ;
    end
end


%% =====================  Initialization =====================

%initialize weighted_distX
SUM = zeros(num);
for i = 1:v
    distX_initial(:,:,i) =  L2_distance_1( X{i}',X{i}' ) ;                  %initialize X
    SUM = SUM + distX_initial(:,:,i);
end
distX = 1/v*SUM;
[distXs, idx] = sort(distX,2);

%initialize S
S = zeros(num);
rr = zeros(num,1);
for i = 1:num
    di = distXs(i,2:k+2);
    rr(i) = 0.5*(k*di(k+1)-sum(di(1:k)));
    id = idx(i,2:k+2);
    S(i,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);               %initialize S
end;
alpha = mean(rr);

% initialize F
S = (S+S')/2;                                                         % initialize F
D = diag(sum(S));
L = D - S;
[F, temp, evs]=eig1(L, c, 0);

% if sum(evs(1:c+1)) < 0.00000000001
%     error('The original graph has more than %d connected component', c);
% end;

%% =====================  updating =====================
for iter = 1:NITER
    % update weighted_distX
    SUM = zeros(num,num);
    for i = 1 : v
        if iter ==1
            distX_updated = distX_initial;
        end
        Wv(i) = 0.5/sqrt(sum(sum( distX_updated(:,:,i).*S)));                % update X
        distX_updated(:,:,i) = Wv(i)*distX_updated(:,:,i) ;
        SUM = SUM + distX_updated(:,:,i);
    end
    distX = SUM;
    
    %update S
    distf = L2_distance_1(F',F');
    S = zeros(num);
    for i=1:num                                                         %update A
        idxa0 = idx(i,2:k+1);
        dfi = distf(i,idxa0);
        dxi = distX(i,idxa0);
        ad = -(dxi+lambda*dfi)/(2*alpha);
        S(i,idxa0) = EProjSimplex_new(ad);
    end;
    
    %update F
    S = (S+S')/2;                                                        %update F
    D = diag(sum(S));
    L = D-S;
    L_ul = L((LN+1):num,1:LN);
    L_uu = L((LN+1):num,(LN+1):num);
    F_u = (-1)*L_uu\L_ul*YL;
    F = [YL;F_u];
    
    
    Sum = 0;
    for i = 1:v
        Sum = Sum + Wv(i)*trace(distX_updated(:,:,i)'*S);
    end
    obj(iter) = Sum  + alpha*norm(S,'fro')^2+ 2*lambda*trace(F'*L*F);
    if iter>2 
        ttt=( obj(iter-1)-obj(iter) )/obj(iter-1);
        if ttt < thresh
        break;
        end
    end
  sprintf('iter = %d',iter)
end


%% =====================  Result =====================
[~,Ypre] = max(F_u,[],2);

clear
clc
warning off;

path = './';
addpath(genpath(path));

load('/root/jzq/code_UAMSC/datasets/Caltech101_20.mat')
Y = gnd;

num_views = length(X);
name='norm';
for v = 1:num_views
     X{v} = preprocess(X{v}, name);
end
num_samples = size(X{1}, 1);
num_class = length(unique(Y));


test_time = 1;
missing_rate = 0;
labeled_rate = 0.05;

for test_i = 1:test_time
    %% Generate partial data
    [M, temp_index] = partialData(X, missing_rate, 2);
    Y = reshape(Y, [], 1); % make sure Y is a column vector
    [MX, Ll, Lu, ~] = labelData(M, Y, temp_index, labeled_rate);
    num_labeled = size(Ll, 1);

    [Ypred] = mySemiERLMVSC(MX, Ll, num_samples, num_class);

    ACC = mean(Ypred == Lu);
    disp(['ACC: ' num2str(ACC)]);
end


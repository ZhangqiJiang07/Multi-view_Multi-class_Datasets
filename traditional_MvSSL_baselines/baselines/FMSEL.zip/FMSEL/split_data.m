function [train_index,test_index] = split_data(Y,ratio,times)
% ratio:            ratio of the training data, 
%                   ratio = 80%, for example
%                   Y=1��2��..C
num = size(Y,1);%������
training_num = floor(ratio*num);
for i=1:times
     rand('seed',i);
    train_index(i,:)=sort(randperm(num,training_num));
    test_index(i,:)=sort(setdiff(1:1:num,train_index(i,:)));
end



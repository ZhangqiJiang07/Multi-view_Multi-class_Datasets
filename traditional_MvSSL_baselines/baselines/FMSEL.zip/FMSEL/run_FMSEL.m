%%%% demo_MVAG
clear
addpath('data')
data_name='handwritten'; % MSRC-v1��handwritten��Caltech101-7,ORL 
load(data_name);
viewNum = length(X);
name='norm';
for v = 1:viewNum
     X{v} = preprocess(X{v},name);
end
lamda1 = [1e-1]; % Tr(F'*L*F)
lamda2 = [1e-1;1e1];%% ͶӰ��ʧ
sigma = [1e-3;1e-1];% ||W||_F

Y=TransLabelR(Y);
%% data can be pre-processed by centerization or normalization if necessary
train_ratio=0.8;
times=20;
labeled_ratio=0.40;% 0.1,0.2,0.3,0.4 
%% ORL �ı�Ǳ����ֱ�Ϊ0.10��0.20��0.35��0.45�����б�Ǳ���0.45ʱ�����������ļ�demo_jcd_ORL
%% UMdigit ѵ������0.1����Ǳ����ֱ�Ϊ0.10��0.20��0.30��0.40�����������ļ�demo_jcd_UMdigit
[train_index,test_index] = split_data(Y,train_ratio,times);
train_num=size(train_index,2);
[labeled_index,unlabeled_index] = labeled_unlabeled(Y,train_index,labeled_ratio);
for p1=1:length(lamda1) 
    for p2=1:length(lamda2)
        for p3=1:length(sigma)
             for j=1:times  
                    for v = 1:viewNum
                         Xl{v}=X{v}(labeled_index(j,:),:);
                         Xu{v} =X{v}(unlabeled_index(j,:),:);
                         Xt{v}=X{v}(test_index(j,:),:);
                    end
                 Yl = Y(labeled_index(j,:),:);
                 [W, b, F,S] = FMSEL(Xl,Xu,Yl,lamda1(p1),lamda2(p2),sigma(p3));
                 [~, pre_un] = max(F(size(Yl,1)+1:train_num,:), [], 2);
                 [~,gnd_un] = max(Y(unlabeled_index(j,:),:),[],2);
                 acc_un(j) = mean(gnd_un== pre_un);
                 Ft = zeros(size(Xt{1},1),size(Y,2));
                 flag = 0;
                 for v = 1:viewNum
                    [~,dim(v) ] = size(Xt{v});
                    Ft = Ft +Xt{v}*W((flag+1):(flag + dim(v)),:);
                    flag = flag + dim(v);
                 end
                 Ft=Ft+ones(size(Xt{1},1),1)*b';
                [~,yte_pre] = max(Ft,[],2);  
                [~,gnd_te] = max(Y(test_index(j,:),:),[],2);
                acc_te(j) = mean(gnd_te== yte_pre);
             end
            acc2_un(p1,p2,p3)=mean(acc_un);
            acc2_te(p1,p2,p3)=mean(acc_te);  
            std_un(p1,p2,p3)=std(acc_un);
            std_te(p1,p2,p3)=std(acc_te); 
        end
    end
end
acc3_un=acc2_un(:)'
acc3_te=acc2_te(:)'
std1_un= std_un(:)'
std1_te= std_te(:)'
a
%% ������ѡ���ʵĽ���Ͷ�Ӧ��׼�� ��¼
%% MRSC_v1 
% 0.8/0.1 un 0.8555/0.0280; te 0.8036/0.0463
% 0.8/0.2 un 0.9019/0.0272; te 0.9107/0.0456
% 0.8/0.3 un 0.9521/0.0239; te 0.9571/0.0315
% 0.8/0.4 un 0.9643/0.0238; te 0.9702/0.0203

%% FMSEL HW 
% 0.8/0.1 un 0.9699/0.0062; te 0.9707/0.0078

% 0.8/0.2 un 0.9793/0.0048; te 0.9752/0.0066
% 0.8/0.3 un 0.9852/0.0025; te 0.9836/0.0046
% 0.8/0.4 un 0.9876/0.0031; te 0.9860/0.0055
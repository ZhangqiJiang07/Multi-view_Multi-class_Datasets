function [W, b, Ypred, S] = myFMSEL(Xl,Xu,Yl,lamda1,lamda2,sigma)
NITER=30;
v = length(Xl);
As=cell(v,1);
flag=0;
k=7;
for i = 1:v
    X{i} = [Xl{i}; Xu{i}];
    As{i}= constructW_PKN(X{i}',k,0);
    [~,dim(i) ] = size(X{i});
    XX(:,(flag+1):(flag + dim(i))) = [X{i}];%n*d 
    flag = flag + dim(i);
end

n = size(X{1}, 1);
c=size(Yl,2);
ln = size(Yl, 1);
un = ln+1;
u=zeros(n,1);
u(1:ln)=1000;
u(un:n)=0.001;
%% initialize F
F = rand(n, c);
F(1:ln, :) = Yl;
Y=F;
%% initialize S & alphav
S = zeros(size(As{1}));
for idx = 1:v
	S = S + As{idx};
end
S = S ./ v;

alphav = ones(size(As)) ./ v;
d=sum(dim);
XX=XX';
Xm = mean(XX,2);
Xc = XX - Xm*ones(1,n);
if d < n
    St = Xc*Xc';
    A = inv(St+sigma*eye(d))*Xc;
else
    K = Xc'*Xc;
    A =Xc*inv(K+ sigma*eye(n));
end;


Lc = eye(n) - 1/n*ones(n);

for iter = 1:NITER

	%% construct Ls
	Ss = (S + S') / 2;
	Ds = diag(sum(Ss));
    Ls = Ds -Ss;
%     sqrtD = diag(sum(Ss).^-.5);
%     Ls = eye(n) - sqrtD * Ss *sqrtD;
    
	%% solve S
    d = L2_distance_1(F',F');
    S = zeros(n);
    
    for i=1:n
        a0 = zeros(1, n);
        for idx = 1:v
        	a0 = a0 + alphav(idx)*As{idx}(i, :);
        end
        S(i, :) = EProjSimplex_new(a0 - d(i, :)*lamda1/4 );
    end

    %% solve alphav
    BigA = zeros(n*n, v);
    for iidx = 1:v
        BigA(:, iidx) = As{iidx}(:);
    end
    P = BigA'*BigA;
    Q = 2*BigA'*(S(:));
    alphav = SimplexQP( P, Q, 200, 1.01, 0, alphav );
    
    %% Update F, W and b
    M = diag(u) + lamda1*Ls +lamda2*(Lc-Xc'*A);
    F = M\(diag(u)*Y);
    W = A*F;
    b = 1/n*(sum(F,1)' - W'*XX*ones(n,1));
  %% caculated OBJ
   
         B1=trace((F-Y)'.*repmat(u',size(Y,2),1)*(F-Y));
         B2= lamda1*trace(F'*Ls*F);
         B3=lamda2*trace((XX'*W+ones(n,1)*b'-F)'*(XX'*W+ones(n,1)*b'-F));
         for j=1:v
             Aa=alphav(j)*As{j};
         end
         B4=norm(S-Aa, 'fro' )^2;
         B5=lamda2*sigma*trace(W'*W);        
         obj(iter)=B1+B2+B3+B4+B5;
         if iter>2
            if abs((obj(iter-1)-obj(iter))/obj(iter-1))<0.01
             break
            end
         end
    
end

% Final prediction
Fu = F(ln+1:end, :);
[~, Ypred] = max(Fu, [], 2);


end
function [labeled_index,unlabeled_index] = labeled_unlabeled(Y,train_index,labeled_ratio)
% % c:                number of class
% % labeled_ratio:    ratio of the labeled data in each class, 
% %                   ratio = 20%, for example
% %                   Y=1��2��..C
% 
% 
% [times,num]=size(train_index);  
% c=size(Y,2);
% if mod(labeled_ratio*num,c)>=c/2
%    labeled_class_num = floor(labeled_ratio*num/c)+1;
% else
%    labeled_class_num = floor(labeled_ratio*num/c);
% end
% % Each class have the same size of labeled data
% 
% for  j=1:times
% 
%     flag1=0;
%     flag2=0;
%     [~,Y_train]=max(Y(train_index(j,:),:),[],2); 
%     for i = 1:c
%          rand('seed',j*c);
%         class_num(i)=size(find(Y_train==i),1);
%         labeled((flag1+1):(flag1 + labeled_class_num)) = randperm(class_num(i),labeled_class_num)+flag2;
%         flag1 = flag1 +  labeled_class_num;
%         flag2 = flag2 +  class_num(i);
%     end
%   labeled_index(j,:)=train_index(j,sort(labeled));
%   unlabeled_index(j,:)= setdiff(train_index(j,:),labeled_index(j,:)); % the No. of unlabeled data
% end
    
% c:                number of class
% labeled_ratio:    ratio of the labeled data in each class, 
%                   ratio = 20%, for example
%                   Y=1��2��..C


[times,num]=size(train_index);  
c=size(Y,2);
if mod(labeled_ratio*num,c)>=c/2
   labeled_class_num = floor(labeled_ratio*num/c)+1;
else
   labeled_class_num = floor(labeled_ratio*num/c);
end
% Each class have the same size of labeled data
labeled_index1=zeros(times,floor(labeled_ratio*num)+50);
for  j=1:times
    
    flag1=0;
    flag2=0;
    [~,Y_train]=max(Y(train_index(j,:),:),[],2); 
    for i = 1:c
        class_num(i)=size(find(Y_train==i),1);
    end
    if min(class_num)>=labeled_class_num
        for i = 1:c
            rand('seed',j*c);
            labeled((flag1+1):(flag1 + labeled_class_num)) = randperm(class_num(i),labeled_class_num)+flag2;
            flag1 = flag1 +  labeled_class_num;
            flag2 = flag2 +  class_num(i);
        end
        labeled_index(j,:)=train_index(j,sort(labeled));
        unlabeled_index(j,:)= setdiff(train_index(j,:),labeled_index(j,:)); % the No. of unlabeled data
    end 
    if min(class_num)<labeled_class_num
        for i = 1:c
            rand('seed',j*c);
            labeled_class_numi=floor(class_num(i)*labeled_ratio);
            labeled((flag1+1):(flag1 + labeled_class_numi)) = randperm(class_num(i),labeled_class_numi)+flag2;
            flag1 = flag1 +  labeled_class_numi;
            flag2 = flag2 +  class_num(i);
        end
       labeled_num(j)=size(labeled,2);
       labeled_index1(j,1:labeled_num(j))=train_index(j,sort(labeled));
       clear labeled
    end

end
if min(class_num)<labeled_class_num
    len=min(labeled_num);
    for  j=1:times  
       labeled_index(j,:)=labeled_index1(j,1:len);
       unlabeled_index(j,:)= setdiff(train_index(j,:),labeled_index(j,:)); % the No. of unlabeled data
    end
end

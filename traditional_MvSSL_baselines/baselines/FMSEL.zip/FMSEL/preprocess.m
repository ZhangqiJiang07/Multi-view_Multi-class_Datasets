function x = preprocess(x,name)
    N = size(x,1);
    switch lower(name)
        case '0-1'%'-1-1'
            x_min = min(x);
            x_max = max(x);
            x_min = repmat(x_min,N,1);
            x_max = repmat(x_max,N,1);
            x = (x-x_min)./(x_max-x_min);
%             x = 2*x-1;
        case '-1-1'%'-1-1'
            x_min = min(x);
            x_max = max(x);
            x_min = repmat(x_min,N,1);
            x_max = repmat(x_max,N,1);
            x = (x-x_min)./(x_max-x_min);
            x = 2*x-1;
        case 'norm'
            x_mean = mean(x);
            x_std = std(x);
            x_mean = repmat(x_mean,N,1);
            x_std = repmat(x_std,N,1);
            x = (x-x_mean)./x_std;
        case 'normalization'
            Norm = arrayfun(@(z)norm(x(z,:)),1:size(x,1))';
            x = x./repmat(Norm,1,size(x,2));
        case 'no'
            x = x;
    end
     
end
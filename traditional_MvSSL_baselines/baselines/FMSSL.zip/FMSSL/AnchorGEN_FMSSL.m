% X:num*dim
%alpha:regulization num
%numanchor:the real number of anchors is 2^numAnchor
%[1] F. Nie, W. Zhu, and X. Li, "Unsupervised Large Graph Embedding," AAAI2017.
%[2] W. Zhu, F. Nie, and X. Li, "Fast Spectral Clustering with Efficient Large
%Graph Construction," ICASSP2017.
function [Z,M] = AGf(X,numAnchor,numNearestAnchor,selAnchor)

% BKHK 1
% K-means++ 2
% K-means 3
% Random 4
if nargin<4
    selAnchor = 1; % BKHK as default
end
% Multi-view setup
X_append = [];
xLen = [];
for i = 1:max(size(X))
    X_append = [X_append X{i}];
    xLen = [xLen size(X{i}, 2)];
end



[num,d] = size(X_append);

if selAnchor == 1 % BKHK
    [~,locAnchor] = hKM(X_append',[1 :num],numAnchor,1);
elseif selAnchor == 2 % kmeans++
    [~,locAnchor] = kmeans(X_append,2^(numAnchor),'Start','plus');
    locAnchor = locAnchor';
elseif selAnchor == 3 % kmeans
    [~,locAnchor] = kmeans(X_append,2^(numAnchor),'Start','sample');
    locAnchor = locAnchor';
elseif selAnchor == 4 % Random
    RandIDX = randperm(num,2^(numAnchor));
    locAnchor = X_append(RandIDX,:);locAnchor = locAnchor';
end


tempLen = 0;
for i=1:max(size(X))
    M{i}=locAnchor(tempLen+1:tempLen+xLen(i), :)'; %m*d_v
    Z{i} = InitializeAG(X{i}', M{i}', numNearestAnchor); % 
    tempLen = tempLen + xLen(i);
end

% Z = ConstructA_NP(X',(locAnchor),numNearestAnchor);
% Z = InitializeAG(X_append',(locAnchor),numNearestAnchor);
end










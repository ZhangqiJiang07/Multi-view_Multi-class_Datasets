

% %   uuuu=M(1,6);
   uuuu=X;
kk=gnd;
[ACC,Fscore]=mainprocedure1(uuuu,kk);


function [ACC,Fscore] = mainprocedure1(X,Label)
g=[];
ff=[];
kall = 5;
Ntime = 10;
tr = 0;
C = max(Label)-min(Label)+1;
l = 0.1;
for pratio = 0:0.1:0.5   %%%����partialdata��labeldata
    tr = tr+1;
    for ti = 1:1:Ntime
        [M1,Index1] = partialdata(X,pratio);
        [M, Ll, Lu, Index] = labeldata(M1,Label,Index1,l);
        nu = size(Lu,1);
        v_idx=[];
        for c = 1:C
            cc = find(Lu==c);
            ncl = ceil(max(size(cc))/1);
            dd = randperm(max(size(cc)),ncl);
            v_idx = [v_idx;cc(dd)];
        end
      
 
        %% My Method
        T = 0;
        b = 0;
        %% ��һ��
        for v=1:max(size(M))
            m(v) = 200;
            %% �ڶ���
            %               m(v) = sum(Index(:,v));
        end
%         save M M;
         Z = partialanchors1(M,Index,m,kall,Label);
%        for p = 0.1:0.4:0.9
%         for p = 0.5
%             b=b+1;
%             a = 0;
%             for j = 1.1:0.4:3.1
%                 %             for j = 1.1
%                 a = a+1;
%                 pmssPara.r = j;
%                 pmssPara.p = p;
%                 tic
%                 [Ypmss,Out] = pmss2( Ll, Index, Z, pmssPara);
%                 toc
%                 
%                 %             tic
%                 %             [Ypmss,Out] = pmss2( Ll, Index, Z, pmssPara);
%                 %             toc
%                 [AC,Fs] = accfscore(Ypmss(v_idx),Lu(v_idx));
%              
%                 [AC1,Fs1] = accfscore(Ypmss,Lu)
%  
%                 
%                 Macc(b,a) = AC;
%                 
%                 
%                
%                 if AC+Fs>=T
%                     [AC1,Fs1] = accfscore(Ypmss,Lu);
%                     ACCpmss(ti,tr) = AC1;
%                     Fscorepmss(ti,tr) = Fs1;
%                     T = AC+Fs;
%                 end
%                  g=[g;AC1];
%                 ff=[ff;Fs1];
%             end
%         end
%           ACC = ACCpmss;
%         Fscore = Fscorepmss;
%         
                
% %  
        %% SLIM
%         T = 0;
%         lam1 = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
%         %         lam1 = 1e3;
%         lam2 = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
%         %         lam2 = 1e3;
%         for i = 1:2:9
%             %         for i = 1:9
%             %             for j = 1
%             for j = 1:2:9
%                 options.lam1 = lam1(i);
%                 options.lam2 = lam2(j);
%                 options.stop = 1e-4;
%                 [Yslim,f,obj] = SLIM(M,Ll,Index,options);
%                 [AC,Fs] = accfscore(Yslim(v_idx),Lu(v_idx))
%                                  g=[g;AC];
%                   ff=[ff;Fs];
%                 MA(i,j) = AC;
%                 if AC+Fs>=T
%                     [AC1,Fs1] = accfscore(Yslim,Lu);
%                     blam1 = lam1(i);
%                     blam2 = lam2(j);
%                     ACCslim(ti,tr) = AC1;
%                     Fscoreslim(ti,tr) = Fs1;
%                     T = AC+Fs;
%                 end
%             end
%         end
%          ACC = ACCslim;
%            Fscore = Fscoreslim;
    
%         % vlp
%         [Yvlp] = newVLP2(M, Z, Ll, Index);
%         [ACCvlp(ti,tr),Fscorevlp(ti,tr)] = accfscore(Yvlp,Lu)
% %         knernel completion
        [KH,S] = creatKHS(Z,Index);
        algorithm_choose = 'algorithm0';
        qnorm = 2;
        [P,gamma,obj,KA] = myabsentmultikernelclustering(KH,S,C,qnorm,algorithm_choose);
        [Ymkkm] = newLP(P,Ll,kall);
        [ACCmkkm(ti,tr),Fscoremkkm(ti,tr)] = accfscore(Ymkkm,Lu);
        Al = zeros(size(Index,1),size(Index,1));
        for v=1:max(size(M))
            A2{v} = KA(:,:,v);
            Al = Al + gamma(v)^2*KA(:,:,v);
        end
        [Ymkkm2] = newLP2(Al,Ll);
        [ACCmkkm2(ti,tr),Fscoremkkm2(ti,tr)] = accfscore(Ymkkm2,Lu);
%         %% AMGL
        tic;
        [Yamgl2] = AMGL_Semi(A2,Ll);
        Tamgl2(tr) = toc;
        [ACCamgl2(ti,tr),Fscoreamgl2(ti,tr)] = accfscore(Yamgl2,Lu)
%         %% AMMSSL
%         T = 0;
%         aa = 0;
%         %KSA:t=0.5 Sec15:0.5
%         for t = 0.1:0.2:0.5
%             aa = aa+1;
%             bb = 0;
%             %KSA:lam=0.9 Sec15:0.9
%             for lam = 0.1:0.4:0.9
%                 bb = bb+1;
%                 r = 10^t;
%                 inPara.r = r;
%                 inPara.lambda = lam;
%                 tic;
%                 [Yammss2,~] = weightMMSSL(A2, Ll, inPara);
%                 Tammssl(tr) = toc;
%                 [AC,Fs] = accfscore(Yammss2(v_idx),Lu(v_idx));
%                 if AC+Fs>T
%                     blam1 = lam;
%                     br1 = r;
%                     [AC1,Fs1] = accfscore(Yammss2,Lu);
%                     ACCammssl2(ti,tr) = AC1;
%                     Fscoreammssl2(ti,tr) = Fs1;
%                     T = AC+Fs;
%                 end
%             end
%         end
        %% Matrix Completion
%         if C<10
%             kc = 10;
%         else
%             kc = C;
%         end
%         [XC] = matrixcomp(M,kc);
%         [A] = csgraph(XC,kall);
%         
%         %% AMMSSL
%         T = 0;
%         aa = 0;
%         %KSA:lam=0.5 Sec15:0.3
%         %         for t = 0.5
%         for t = 0.1:0.2:0.5
%             aa = aa+1;
%             bb = 0;
%             %             for lam = 0.5
%             %KSA:lam=0.5 Sec15:0.5
%             for lam = 0.1:0.4:0.9
%                 bb = bb+1;
%                 r = 10^t;
%                 inPara.r = r;
%                 inPara.lambda = lam;
%                 tic;
%                 [Yammssl,~] = weightMMSSL(A, Ll, inPara);
%                 Tammssl(tr) = toc
%                 [AC,Fs] = accfscore(Yammssl(v_idx),Lu(v_idx));
%                 if AC+Fs>T
%                     blam2 = lam;
%                     br2 = r;
%                     [AC1,Fs1] = accfscore(Yammssl,Lu);
%                     ACCammssl(ti,tr) = AC1;
%                     Fscoreammssl(ti,tr) = Fs1;
%                     T = AC+Fs;
%                 end
%             end
%         end
        
        %% AMGL
%         tic;
%         [Yamgl] = AMGL_Semi(A,Ll);
%         Tamgl(tr) = toc
%         [ACCamgl(ti,tr),Fscoreamgl(ti,tr)] = accfscore(Yamgl,Lu);
%         
        %% IMVL
%         for v=1:max(size(M))
%             M1{v} = M{v}';
%             [dim(v), n] = size(M1{v});
%             Z0{v} = rand(dim(v),n);
%             tt = find(Index(:,v)==1);
%             Z0{v}(:,tt) = Z0{v}(:,tt);
%             O = zeros(dim(v), n);
%             O(:,tt) = 1;
%             Omega{v} = find(O>0);
%         end
%         W0 = rand(C,n);
%         [ ~, P, ~, ~, ~ , ~] = MVL_IV(M1, Omega, Z0, W0);
%         [YIMVL] = newLP(P',Ll,kall);
%         [ACCimvl(ti,tr),Fscoreimvl(ti,tr)] = accfscore(YIMVL,Lu)
% %     end
%  end

% ACC.VLP = ACCvlp;
% ACC.ammssl = ACCammssl;
% ACC.amgl = ACCamgl;
% ACC.ammssl2 = ACCammssl2;
% ACC.amgl2 = ACCamgl2;
% ACC.mkkm = ACCmkkm;
% ACC.mkkm2 = ACCmkkm2;
% ACC.IMVL = ACCimvl;
%   ACC.pmss = ACCpmss
% ACC.slim = ACCslim;
%  
% Fscore.VLP = Fscorevlp;
% Fscore.ammssl = Fscoreammssl;
% Fscore.amgl = Fscoreamgl;
% Fscore.ammssl2 = Fscoreammssl2;
% Fscore.amgl2 = Fscoreamgl2;
% Fscore.mkkm = Fscoremkkm;
% Fscore.mkkm2 = Fscoremkkm2;
% Fscore.IMVL =  Fscoreimvl;
%   Fscore.pmss =  Fscorepmss
% % Fscore.slim = Fscoreslim;
save g g
%    save ACC.pmss ACC.pmss;
save  ff ff
%   save Fscorepmss Fscorepmss;
     end
end
end
%   end
function [Z]= partialanchors1(X,index,m,k,Label)
     V = max(size(X));
% % % % 
      for v=1:V
            t = find(index(:,v)==1);
% % % % % % % %      Z{v} = myconstructAnchor(X{v}(t,:), m(v), k);
          T = X{v}(t,:)';
% % %     kk=length(size(T));
% % 
                  Z{v} = constructAnchorDistance_PKN( T, m(v),k);
% %   
%      beta=0.5;
%     m=30;
%            [Z,obj]=  algo_AZ(X,Label,m,beta);
%             for i=1:numel(Z)
%              
% %             Z{i}(isnan(Z{i})==1)=0;
% %        
% %              if sum(sum(isnan(Z{i})))>0
% %      Z{i}(isnan(Z{i})==1)=1;
% %   
% % %             end
%      Z{i}(isnan( Z{i})) = 0;
%    T = sum(Z{i}, 1);
%    Z{i}(:,find(T==0))=[];
% 
%    Z{i} = Z{i}';
%     s0=sum(Z{i},2);%length(find(isnan(s0)))
%     Z{i}=Z{i}./repmat(s0,1,size(Z{i},2));
            end

%     save k k;
% save  Z Z
   end
%     end

function [M, Ll, Lu, Index] = labeldata(X,L,IndexO,L_ratio)
View = max(size(X));
C = max(L)-min(L)+1;
nV = sum(IndexO,2);

ic = [];
for c = 1:C
    cc = find(L==c);    
    ncl = ceil(max(size(cc))*L_ratio);
    nVc = nV(cc);
    for v = View:-1:1
        Ls = find(nVc==v);
        ts = size(Ls,1);
        if ts>ncl
          tc = randperm(ts,ncl);
          ic = [ic;cc(Ls(tc))];
          break;
        else
          ic = [ic;cc(Ls)];
          ncl = ncl-ts;
        end
    end
end
Ll = L(ic);
L(ic)=[];
Lu = L;

Index = IndexO(ic,:);
IndexO(ic,:) = [];
Index = [Index;IndexO];

for v = 1:View
M{v} = X{v}(ic,:);
X{v}(ic,:) = [];
M{v} = [M{v};X{v}];
end 
end

function [M,Index] = partialdata(X,P_ratio)
V = max(size(X));
num = size(X{1},1);
% for i = 1 :V
%     for  j = 1:num
%         X{i}(j,:) = ( X{i}(j,:) - mean( X{i}(j,:) ) ) / std( X{i}(j,:) ) ;
%     end
% end
Index = ones(num,V);
P_r = 100*P_ratio;
M = X;
for i = 1:num
    for v = 1:V
        aa = randperm(100,1);
        if aa<=P_r
            M{v}(i,:) = nan;
            Index(i,v) = 0;
        end
    end
    if sum(Index(i,:))==0
        bb = randperm(v,1);
        M{bb}(i,:) = X{bb}(i,:);
        Index(i,bb) = 1;
    end
end

%% Normalization 
%  for v = 1:V
%     T1 = find(Index(:,v)==1);
%     T2 = M{v}(T1,:);
%     aa = max(max(T2));
%     bb = min(min(T2));
%     M{v}(T1,:) = (T2-bb)/(aa-bb);
%  end
%MNIST
for v = 1:V
    T1 = find(Index(:,v)==1);
    T2 = M{v}(T1,:);
    T3 =  mapminmax(T2',0,1);
    M{v}(T1,:) = T3';
end
end
% for v = 1:V
%     T1 = find(Index(:,v)==1);
%     T2 = M{v}(T1,:);
%     T3 =  mapminmax(T2,0,1);
%     M{v}(T1,:) = T3;
% end
%  for v = 1:V
%     T1 = find(Index(:,v)==1);
%     T2 = M{v}(T1,:);
%     meanx = mean(T2); stdx = std(T2)+1e-8;
%     M{v}(find(Index(:,v)==1),:) = (T2 - repmat(meanx,sum(Index(:,v)),1))./repmat(stdx,sum(Index(:,v)),1);
%  end
%  for v= 1:V
%  for  j = 1:size(M{v})
%       normit = norm(M{v}(j,:)); 
%       if (normit<1e-10)
%            normit = 1e-10;
%       end;
%       M{v}(j,:) = M{v}(j,:)/normit;
%  end
%  end
%  for v = 1:V
%     T1 = find(Index(:,v)==1);
%     T2 = M{v}(T1,:);
%     T3 = T2';
%     stdf = std(T3)+1e-8;
%     meanf = mean(T3);
%     T4 = (T3-repmat(meanf,size(T3,1),1))./repmat(stdf,size(T3,1),1);
%     M{v}(find(Index(:,v)==1),:) = T4';
%  end
%   for v = 1:V
%     T1 = find(Index(:,v)==1);
%     T2 = M{v}(T1,:);
%     T3 = T2';
%     meanf = mean(T3);
%     T3 = T3-repmat(meanf,size(T3,1),1);
%     T4 = T3;
%     for j = 1:size(T3,1)
%         normit = norm(T3(j,:))+1e-8;
%         T4(j,:) = T3(j,:)/normit;
%     end
%     M{v}(find(Index(:,v)==1),:) = T4';
%  end







function [Ypre,Out ] = pmss2(Ll, Index, Z ,inPara)
maxIter = 30;
thresh = 1e-4;
p = inPara.p;%%%�ṹ�幹����  
r = inPara.r;
for i=1:length(Z)
   Z{i}(isnan(Z{i})) = 0;
end
View = max(size(Z));
n = size(Index,1);
nl = size(Ll,1);
nu = n-nl;
nc = max(Ll)-min(Ll)+1;
%% construct graphs
for v=1:View
   %% Initilization
   %% alpha
   alpha(v) = 1/View;
   V_ind{v} = find(Index(:,v)==1);
   Vl_ind{v} = V_ind{v}(V_ind{v}<=nl);
   Vu_ind{v} = V_ind{v}(V_ind{v}>nl);
   F{v} = zeros(n,nc);
   H{v} = zeros(n,nc);
   nv(v) = sum(Index(:,v));
   e{v} = sum(Z{v},1);
   te = find(e{v}>0.01);
   A{v} = Z{v}(:,te)*diag(e{v}(te).^(-1))*Z{v}(:,te)';
   D{v} = sum(Z{v},2);
   L{v} = diag(D{v})-A{v};
end
Y = zeros(n,nc);
for i = 1:nl
    Y(i,Ll(i)) = 1;
end
Y((i+1):end,:) = 1/nc;
YG = Y.^(r);
U = sum(YG,2);

for iter = 1:maxIter
    fprintf('ansmsc iteration %d...\n', iter);
   %% given GC, update F{v}
          
     for v = 1:View
%          kk=[];
%        for mm=1:length(Index)
%          kk=[kk;mm];
%    
%          end
%         V_ind{v}=kk;
%          if size(diag(U(V_ind{v})))==size(L{v})
%         mm=diag(U(V_ind{v}));
        AA = diag(U(V_ind{v}))+2*L{v};
        BB = YG(V_ind{v},:);
        F{v}(V_ind{v},:) = AA\BB;
%         end
        
    end
    %% Update label matrix Y
    Yut = zeros(n,nc);
    for v = 1:View
        H{v}(Vl_ind{v},:) = (F{v}(Vl_ind{v},:)-Y(Vl_ind{v},:)).^2;
        Tu1 = (F{v}(Vu_ind{v},:)-ones(max(size(Vu_ind{v})),nc)).^2; 
        Tu2 = F{v}(Vu_ind{v},:).^2;
        Tu2s = sum(Tu2,2);
        for c = 1:nc
            H{v}(Vu_ind{v},c) = Tu2s-Tu2(:,c)+Tu1(:,c);
            Yut(Vu_ind{v},c) = Yut(Vu_ind{v},c)+alpha(v)*H{v}(Vu_ind{v},c);  
        end
    end
    if (r==1)
        Yu = zeros(nu,nc);
        [~,YII]=min(Yut((nl+1):end,:)');
        for i = 1:nu
            Yu(i,YII(i)) = 1;
        end
    else
        Yut = (r.*Yut((nl+1):end,:)).^(1/(1-r));
        s0=sum(Yut,2);%length(find(isnan(s0)))
        Yu=Yut./repmat(s0,1,nc);
        Yu(isnan(Yu)==1)=1;
    end
    Y((nl+1):end,:) = Yu;
    YG((nl+1):end,:) = Yu.^(r);
    U((nl+1):end,:) = sum(YG((nl+1):end,:),2);
    
    %% update alpha
    for v = 1:View
        dist = L2_distance(F{v}(V_ind{v},:)',F{v}(V_ind{v},:)');
        if size (A{v})==size(dist)
        g(v) = sum(sum(A{v}.*dist));
        g(v) = g(v)+sum(sum(YG(Vu_ind{v},:).*H{v}(Vu_ind{v},:)));
        g(v) = g(v)/nv(v);
        alpha(v) = g(v).^(p-1);
        end
    end  
    
   %% calculate the objective
    obj(iter) = sum(g.^p);
    if(iter > 2)
        obj_diff = (obj(iter-1) - obj(iter))/obj(iter-1);
        if(obj_diff < thresh)
            break;
        end
    end
end
outObj = obj(2:iter);
[~,Ypre] = max(Yu,[],2);
Out.obj = outObj;
Out.Alpha = alpha;
Out.Yu = Yu;

end
%  [Zi,A,iter,obj] = algo_AZ(X,Y,m,beta)

function z = constructAnchorDistance_PKN( X, m,k)
%KNNDISTANCE Summary of this function goes here
%   Detailed explanation goes here

% X: each column is a data point
% anchors: each column is a data point
% nRepeat: the execute time to repeat


r=1.5;
maxIter=30;
[~,n]=size(X);
% in large folder, change filename because name conflict
 [G]=initialG(m,n);
%         [label,center, F] =   fcm1(X,m,r,maxIter);
           [label,~,~,center, obj] =   kmeans1(X, G);
%       [label,center, obj] = cluster1(X);
ct=center;

lb=label;
ub=unique(lb);
 save lb lb
 save ct ct
anchors=zeros(size(X,1),m);
save anchors anchors
len=length(ub);
for i=1:len
    anchors(:,i)=ct(:,ub(i));
end

left=m-len;
if left>0
    ns=tabulate(lb);
    ns=ns(:,3)./100;
    ns=floor((m-len)*ns);
    left=left-sum(ns);
    while left>0
        if left>len
            ns=ns+1;
            left=left-len;
        else
            sl=randsample(len,left,0);
            for i=1:size(sl,1)
                l=sl(i);
                ns(l)=ns(l)+1;
            end
            break;
        end
    end
    
    ptr=len+1;
    for i=1:len
        if ns(i)>0 &find(lb==i)>0
            
            
                 sl=randsample(find(lb==i),ns(i));
%                  sl=1;
%             save sl sl
            for j=1:length(sl)
                anchors(:,ptr)=X(:,sl(j));
                ptr=ptr+1;
            end
        end
    end
end

D = L2_distance(X,anchors);
D(D<0) = 0;

if nargin<3 || k>=size(anchors,2)
    k=size(anchors,2)-1;
end

[~ , idx] = sort(D, 2); % sort each row
num=size(X,2);
z = zeros(num,m);
for i = 1:num
    id = idx(i,1:k);
    di = D(i, idx(i,1:k+1));
    z(i,id) = (di(k+1)-di(1:k))/(k*di(k+1)-sum(di(1:k)));
end;
if sum(sum(isnan(z)))>0
    z(isnan(z)==1)=1;
    s0=sum(z,2);%length(find(isnan(s0)))
    z=z./repmat(s0,1,size(z,2));
end
clear D idx;
T = sum(z,1);
z(:,find(T==0))=[];
%  save z  z;
end
function[G]=initialG(C,num)
I = eye(C);   
R = randperm(size(I,1)); 
g = ceil(num/C);
inG0 = repmat(I(R,:),g,1); 
G0 = inG0(1:num,:);
[~,G] = max(G0,[],2);
end



function [label, iter_num, sumd, center, obj] = kmeans1(X, label)
% X: dim*n matrix, each column is a data point
% label: cluster number or initial label vector

n = size(X,2);
last = 0;
if isscalar(label)
    %label = randsrc(n,1,1:label);
    label = ceil(label*rand(n,1));  % random initialization
elseif n ~= length(label)
    error('each row should be a data point');
end

k = length(unique(label));
iter_num = 0;
while any(label ~= last)
    [dumb,dumb1,label] = unique(label);   % remove empty clusters
    E = sparse(1:n,label,1,n,k,n);  % transform label into indicator matrix
    center = X*(E*spdiags(1./sum(E,1)',0,k,k));    % compute center of each cluster
    last = label;
    [dumb,label] = max(bsxfun(@minus,center'*X,0.5*sum(center.^2,1)'),[],1); % assign samples to the nearest centers
    label = label';
    iter_num = iter_num+1;
    if iter_num>100
        break;
    end
end
  save center center

if nargout > 2
    for ii=1:k
        idxi = find(label==ii);
        Xi = (X(:,idxi));
        ceni = mean(Xi,2);
        center(:,ii) = ceni;
        c2 = ceni'*ceni;
        d2c = sum(Xi.^2) + c2 - 2*ceni'*Xi;
        sumd(ii,1) = sum(d2c);
    end
    obj = sum(sumd);
end
% save label label
end
function [label,center, obj] = cluster1(X)
% X: dim*n matrix, each column is a data point
% label: cluster number or initial label vector
n = size(X,2);
% 1. ����������
D = pdist(X','euclidean');

% 2. ������ξ�����
Z = linkage(D);

% 3. ȷ������
num_clusters = 100; % �ص�����
T = cluster(Z,'maxclust',num_clusters); % ����ʹ�� T = cluster(Z,'cutoff',distance) 
label=T;
% save label label
% end
 clusters = unique(label);
% 4. ���������λ��
k = length(unique(label));
 E = sparse(1:n,label,1,n,k,n);  % transform label into indicator matrix
    center = X*(E*spdiags(1./sum(E,1)',0,k,k));    % compute center of each cluster
 save center center
% obj = 10;
%  for i = 1:num_clusters
%      centers(i, :) = mean(X(T == i, :), 1);
%      obj = obj + sum(sum((X(T == i, :) - ones(sum(T == i), 1) * centers(i, :)).^2));
%  end
    for ii=1:k
        idxi = find(label==ii);
        Xi = X(:,idxi);
        ceni = mean(Xi,2);
        center(:,ii) = ceni;
        c2 = ceni'*ceni;
        d2c = sum(Xi.^2) + c2 - 2*ceni'*Xi;
        sumd(ii,1) = sum(d2c);
    end
    obj = sum(sumd);

 end
function  [AC,Fs] = accfscore(Ypmss,Lu)
   AC=accuracy1(Ypmss,Lu);
   Fs=macroFbeta1(Ypmss,Lu);
   
end

   
   
function [ score ]= accuracy1(true_labels, cluster_labels)
%ACCURACY Compute clustering accuracy using the true and cluster labels and
%   return the value in 'score'.
%
%   Input  : true_labels    : N-by-1 vector containing true labels
%            cluster_labels : N-by-1 vector containing cluster labels
%
%   Output : score          : clustering accuracy
%
%   Author : Wen-Yen Chen (wychen@alumni.cs.ucsb.edu)
%			 Chih-Jen Lin (cjlin@csie.ntu.edu.tw)

% Compute the confusion matrix 'cmat', where
%   col index is for true label (CAT),
%   row index is for cluster label (CLS).
numcorrect = sum(true_labels==cluster_labels);
accracy = numcorrect/length(true_labels);
score=accracy;
end

function [ macrofbeta ] = macroFbeta1( y_pre, y_true, beta )
% computer the macro fbeta score
%  
if ~exist('beta','var')
    beta = 1;
end
y_true = y_true(:);
y_pre = y_pre(:);
mat=confusionmat(y_true, y_pre);
classNum = size(mat,1);
Fbeta = zeros(classNum,1);
P = zeros(classNum,1);
R = zeros(classNum,1);
for i = 1:classNum
    P(i) = mat(i,i)/sum(mat(:,i));
    R(i) = mat(i,i)/sum(mat(i,:));
    if P(i) == 0 || R(i) == 0
        Fbeta(i) = 0;
    else
        Fbeta(i) = (1+beta^2)*P(i)*R(i)/(beta^2*P(i) + R(i));
    end
end
macrofbeta = mean(Fbeta);

end

function [Ypre,f,obj] = SLIM(X,label,Index,options)
lam1 = options.lam1;
lam2 = options.lam2;
stopc = options.stop;
View = max(size(X));
nC = max(label)-min(label)+1;
num = size(X{1},1);
ln = max(size(label));
H = zeros(num,num);
fu = ones(num-ln,nC)/nC;
fl = zeros(ln,nC);
alpha = 0.3;
beta = 0.8;
maxIter = 5;
ss = 1;
for i = 1:ln
    fl(i,label(i))=1;
end
f = [fl;fu];
for v = 1:View
    X{v}(isnan(X{v})==1)=0;
    %% Calculate H
    TT{v} = Index(:,v)*Index(:,v)';
    O{v} = diag(Index(:,v));
    n(v) = sum(Index(:,v));
    dim(v) = size(X{v},2);
    C{v} = O{v}-TT{v}/n(v);
    B{v} = X{v}'*C{v}';
    invA{v} = B{v}*B{v}'+n(v)*lam1*eye(dim(v));
    AmB{v} = invA{v}\B{v};
    H = H+C{v}'*AmB{v}'*(lam1/2*AmB{v}*C{v}+0.5/n(v)*B{v}*B{v}'*AmB{v}*C{v}-1/n(v)*B{v}*C{v})+0.5/n(v)*C{v}'*C{v};
    %% Construct S{v}
    tempX{v} = zeros(num,dim(v));
    S{v} = zeros(num,num);
    for i = 1:num
        if Index(i,v)==1
            tt = norm(X{v}(i,:)); 
%             tt = 1;
            if tt>0&&isnan(tt)==0
            tempX{v}(i,:) = X{v}(i,:)/tt;
            else
            tempX{v}(i,:) = ones(1,dim(v))/sqrt(dim(v));
            end
        end
    end
    S{v} = tempX{v}*tempX{v}';
end
for iter = 1:maxIter
    fprintf('SLIM iteration %d...\n', iter);
    grad_1 = H * f;
    S_a = f*f';
    grad_2 = zeros(num,nC);
    for v = 1:View
        ST = zeros(num,num);
        ST(TT{v}==1) = S_a(TT{v}==1);
        pro{v} = ST-S{v};
        normv(v) = norm(pro{v},'fro');
        if normv(v) == 0
            pro{v} = 0;
        else
            pro{v} = pro{v}/normv(v);
        end
        grad_2 = grad_2 + pro{v}*f/n(v);
    end
    grad_f = grad_1+grad_2*lam2;
    if iter == 1
        [loss1(iter),loss2(iter)] = SLIM_obj(H,f,S,TT,lam2,n);
        obj(iter) = loss1(iter)+loss2(iter);
    end
    [ssn]= calculatess(f,grad_f,obj(iter),ss,alpha,beta,H,S,TT,lam2,n);
    fn = f-ssn*grad_f;
    ss = ssn; 
    tmp_0 = zeros(size(fn));
	tmp_1 = ones(size(fn));

	fn(find(fn<=0)) = tmp_0(find(fn<=0));
	fn(find(fn>=1)) = tmp_1(find(fn>=1));
    fn(1:ln,:)=f(1:ln,:);
    [loss1(iter+1),loss2(iter+1)] = SLIM_obj(H,fn,S,TT,lam2,n);
    obj(iter+1) = loss1(iter+1)+loss2(iter+1);
    if iter>1 && (abs(obj(iter+1)-obj(iter))/obj(iter+1)<stopc)
		fprintf('Object value converge to %.4f at iteration %d before the max OUTer Iteration reached\n', obj(iter), iter);
		break;
    end
    f = fn;
end
[~,Ypre] = max(f(ln+1:end,:),[],2);
end
function [loss1,loss2]=SLIM_obj(H,f,S,TT,lam2,n)
loss1 = trace(f'*H*f);
num = size(f,1);
V = max(size(S));
loss2 = 0;
S_a = f*f';
for v=1:V
    ST = zeros(num,num);
    ST(TT{v}==1) = S_a(TT{v}==1);
    loss2=loss2+lam2/(2*n(v))*norm((ST-S{v}),'fro');
end
end
function [ssn,objl] = calculatess(f,grad_f,obj1,ss,alpha,beta,H,S,TT,lam2,n,ln)
Maxiter = 1000;
obj2 = norm(grad_f,'fro')^2;
for i=1:Maxiter
    objr = obj1-alpha*ss*obj2;
    fn = f-ss*grad_f;
    [loss1,loss2] = SLIM_obj(H,fn,S,TT,lam2,n);
    objl = loss1+loss2;
    if objl<=objr
        ssn = ss;
        break;
    else
        ss = ss*beta;
    end
end
end


function [Ypre,out] = weightMMSSL(A, Ll, inPara)

% solve the following problem: i = 1: V
% min_(G,G_i,G_l=Y_l, alpha_i>=0, sum(alpha_i)=1) 
% sum(alpha_i^r * Trace(G_i'L_iG_i)) + lamda*sum(trace((G_0-G_i)'*(G_0-G_i)))
% input: 
%       inY_tr:  the labeled training label matrix, n_tr by C
%       inPara:  the parameters structure
%                inPara.r: the weights distribution scalor
%                inPara.alpha: the initial weight vector 
%                inPara.lambda: the regularization parameter
% output:
%       outAlpha: the learnt Alpha vector
%       outAlphaR: the learnt Alpha^r vector, i.e. the weight vector for
%                  different view
%       outG_0: the learnt common label indicator matrix, continuous
%       outG_b: the learnt common label indicator matrix, discrete
%       outObj: the obj value of the proposed function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ref:
%%% Xiao Cai, Feiping Nie, Weidong Cai, Heng Huang
%%% Heterogeneous Image Features Integration via Multi-modal 
%%% Semi-supervised Learning Model. ICCV 2013: 1737-1744
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameter setting
maxIter = 30;
thresh = 1e-4;
lambda = inPara.lambda;
r = inPara.r;
l = size(Ll, 1);
inY_tr = zeros(l,max(Ll));
for i=1:l
    inY_tr(i,Ll(i))=1;
end 
if(r == 1)
    r = r+eps;
end
V = max(size(A)); % num of view
for v = 1: V
    A{v} = (A{v}+A{v}')/2;
    d = sum(A{v});       
    D = diag(d);
    inL(:,:,v) = D-A{v};
    alpha(v) = 1/V;
end
clear A��
N = size(inL, 1); % num of data point
C = size(inY_tr,2); % num of class
% pre-calculation
tmp = 1/(1-r);
I = eye(N);
% pre-allocation
outG_0 = zeros(N, C); 
obj = zeros(maxIter, 1);
for iter = 1: maxIter
    fprintf('processing iteration %d...\n', iter);
    % given alpha, update G_0
    H = zeros(N,N);
    for v = 1: V
        TT{v} = inv((alpha(v).^r) * inL(:,:,v)+lambda*I);
        H = H + I-lambda*TT{v};
    end           
    H_uu = H((l+1):end, (l+1):end);
    H_ul = H((l+1):end, 1:l);
    G_0_u = (-1)*H_uu\H_ul*inY_tr;
    G_0 = [inY_tr; G_0_u];
        
    % given G_0, update G
    G = zeros(N, C, V);
    for v = 1: V
        G(:,:,v) = lambda * TT{v} * G_0;
    end
    
    % given G_0, update alpha
    for v = 1:V
        g(v) = trace(G(:,:,v)'*inL(:,:,v)*G(:,:,v));
    end
    alpha = ((r*g).^tmp)/(sum(((r*g).^tmp)));
    
    % calculate the objective
    tt = zeros(V, 1);
    for v = 1: V
        tt(v) = trace((G_0 - G(:,:,v))'*(G_0 - G(:,:,v)));
    end
    obj(iter) = sum((alpha.^r).*g) + lambda * sum(tt);
    if(iter > 2)
        obj_diff = (obj(iter-1) - obj(iter))/obj(iter-1);
        if(obj_diff < thresh)
            break;
        end
    end
end
out.Obj = obj(2:iter);
out.lpha = alpha;
out.AlphaR = alpha.^r;
out.G_0 = G_0;
% discretize the label indicator matrix
[max_value,max_ind] = max(G_0_u,[],2);
Ypre = max_ind;
end


function d = L2_distance(a,b)
% a,b: two matrices. each column is a data
% d:   distance matrix of a and b



if (size(a,1) == 1)
  a = [a; zeros(1,size(a,2))]; 
  b = [b; zeros(1,size(b,2))]; 
end

aa=sum(a.*a); bb=sum(b.*b); ab=a'*b; 
d = repmat(aa',[1 size(bb,2)]) + repmat(bb,[size(aa,2) 1]) - 2*ab;

d = real(d);
d = max(d,0);
end
function [label center,F] = fcm1(X, c, r, max_iter)
% FCM: Fuzzy C-Means clustering algorithm
% Input:
% X: data matrix (d x n)
% c: number of clusters
% r: fuzzifier parameter (r > 1)
% max_iter: maximum number of iterations
% Output:
% F: membership matrix (n x c)
% M: center matrix (d x c)

% Get the dimensions of the input data matrix
X=X;
[d, n] = size(X);

% Initialize the membership matrix F randomly
F = rand(n, c);
F = F ./ sum(F, 2);

% Initialize the center matrix M
center = zeros(d, c);

% Iterate until max_iter is reached
for iter = 1:max_iter
% Update the center matrix M
for j = 1:c
g_j = F(:, j).^r;
center(:, j) = X * g_j / sum(g_j);
end
end
% Update the membership matrix F
for i = 1:n
for j = 1:c
dist = norm(X(:, i) - center(:, j))^2;
temp_sum = sum(arrayfun(@(k) (dist / norm(X(:, i) - center(:, k))^2)^(1 / (r - 1)), 1:c));
F(i, j) = 1 / temp_sum;
end
end
[~, label] = max(F, [], 2);
% save label label
end
function [x ft] = EProjSimplex_new(v, k)       %%%%%%%%%EProjSimplex_new

%
%% Problem
%
%  min  1/2 || x - v||^2
%  s.t. x>=0, 1'x=k
%

if nargin < 2
    k = 1;
end;

ft=1;
n = length(v);

v0 = v-mean(v) + k/n;
%vmax = max(v0);
vmin = min(v0);
if vmin < 0
    f = 1;
    lambda_m = 0;
    while abs(f) > 10^-10
        v1 = v0 - lambda_m;
        posidx = v1>0;
        npos = sum(posidx);
        g = -npos;
        f = sum(v1(posidx)) - k;
        lambda_m = lambda_m - f/g;
        ft=ft+1;
        if ft > 100
            x = max(v1,0);
            break;
        end;
    end;
    x = max(v1,0);

else
    x = v0;
end
end                      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%EProjSimplex_new   end
function [C] = initialize(X,k)       %%%%%%%%%%%%%%%%%%initialize
    
s = RandStream('mt19937ar','Seed',0);
RandStream.setGlobalStream(s);
    
[IDX, C] = kmeans(X,k, 'MaxIter',200,'Replicates',30);
dimension = size(C,2);
%% numclass, 'MaxIter',100, 'Replicates',10
if dimension >= k
    C = orth(C');
    C = C';
else
    C = C;
end
end             %%%%%%%%%%%%%%%%%%initialize          end
% %returns the K cluster centroid locations in the K-by-P matrix C.
function [label, center, bCon, sumD, D] = litekmeans(X, k, varargin)  %%%%%%%litekmeans  

if nargin < 2
    error('litekmeans:TooFewInputs','At least two input arguments required.');
end

[n, p] = size(X);

pnames = {   'distance' 'start'   'maxiter'  'replicates' 'onlinephase' 'clustermaxiter'};
dflts =  {'sqeuclidean' 'sample'       []        []        'off'              []        };
[eid,errmsg,distance,start,maxit,reps,online,clustermaxit] = getargs(pnames, dflts, varargin{:});
if ~isempty(eid)
    error(sprintf('litekmeans:%s',eid),errmsg);
end

if ischar(distance)
    distNames = {'sqeuclidean','cosine'};
    j = strcmpi(distance, distNames);
    j = find(j);
    if length(j) > 1
        error('litekmeans:AmbiguousDistance', ...
            'Ambiguous ''Distance'' parameter value:  %s.', distance);
    elseif isempty(j)
        error('litekmeans:UnknownDistance', ...
            'Unknown ''Distance'' parameter value:  %s.', distance);
    end
    distance = distNames{j};
else
    error('litekmeans:InvalidDistance', ...
        'The ''Distance'' parameter value must be a string.');
end


center = [];
if ischar(start)
    startNames = {'sample','cluster'};
    j = find(strncmpi(start,startNames,length(start)));
    if length(j) > 1
        error(message('litekmeans:AmbiguousStart', start));
    elseif isempty(j)
        error(message('litekmeans:UnknownStart', start));
    elseif isempty(k)
        error('litekmeans:MissingK', ...
            'You must specify the number of clusters, K.');
    end
    if j == 2
        if floor(.1*n) < 5*k
            j = 1;
        end
    end
    start = startNames{j};
elseif isnumeric(start)
    if size(start,2) == p
        center = start;
    elseif (size(start,2) == 1 || size(start,1) == 1)
        center = X(start,:);
    else
        error('litekmeans:MisshapedStart', ...
            'The ''Start'' matrix must have the same number of columns as X.');
    end
    if isempty(k)
        k = size(center,1);
    elseif (k ~= size(center,1))
        error('litekmeans:MisshapedStart', ...
            'The ''Start'' matrix must have K rows.');
    end
    start = 'numeric';
else
    error('litekmeans:InvalidStart', ...
        'The ''Start'' parameter value must be a string or a numeric matrix or array.');
end

% The maximum iteration number is default 100
if isempty(maxit)
    maxit = 100;
end

% The maximum iteration number for preliminary clustering phase on random
% 10% subsamples is default 10 
if isempty(clustermaxit)
    clustermaxit = 10;
end


% Assume one replicate
if isempty(reps) || ~isempty(center)
    reps = 1;
end

if ~(isscalar(k) && isnumeric(k) && isreal(k) && k > 0 && (round(k)==k))
    error('litekmeans:InvalidK', ...
        'X must be a positive integer value.');
elseif n < k
    error('litekmeans:TooManyClusters', ...
        'X must have more rows than the number of clusters.');
end


bestlabel = [];
sumD = zeros(1,k);
bCon = false;

for t=1:reps
    switch start
        case 'sample'
            center = X(randsample(n,k),:);
        case 'cluster'
            Xsubset = X(randsample(n,floor(.1*n)),:);
            [dump, center] = litekmeans(Xsubset, k, varargin{:}, 'start','sample', 'replicates',1 ,'MaxIter',clustermaxit);
        case 'numeric'
    end
    
    last = 0;label=1;
    it=0;
    
    switch distance
        case 'sqeuclidean'
            while any(label ~= last) && it<maxit
                last = label;
                
                bb = full(sum(center.*center,2)');
                ab = full(X*center');
                D = bb(ones(1,n),:) - 2*ab;
                
                [val,label] = min(D,[],2); % assign samples to the nearest centers
                ll = unique(label);
                if length(ll) < k
                    %disp([num2str(k-length(ll)),' clusters dropped at iter ',num2str(it)]);
                    missCluster = 1:k;
                    missCluster(ll) = [];
                    missNum = length(missCluster);
                    
                    aa = sum(X.*X,2);
                    val = aa + val;
                    [dump,idx] = sort(val,1,'descend');
                    label(idx(1:missNum)) = missCluster;
                end
                E = sparse(1:n,label,1,n,k,n);  % transform label into indicator matrix
                center = full((E*spdiags(1./sum(E,1)',0,k,k))'*X);    % compute center of each cluster
                it=it+1;
            end
            if it<maxit
                bCon = true;
            end
            if isempty(bestlabel)
                bestlabel = label;
                bestcenter = center;
                if reps>1
                    if it>=maxit
                        aa = full(sum(X.*X,2));
                        bb = full(sum(center.*center,2));
                        ab = full(X*center');
                        D = bsxfun(@plus,aa,bb') - 2*ab;
                        D(D<0) = 0;
                    else
                        aa = full(sum(X.*X,2));
                        D = aa(:,ones(1,k)) + D;
                        D(D<0) = 0;
                    end
                    D = sqrt(D);
                    for j = 1:k
                        sumD(j) = sum(D(label==j,j));
                    end
                    bestsumD = sumD;
                    bestD = D;
                end
            else
                if it>=maxit
                    aa = full(sum(X.*X,2));
                    bb = full(sum(center.*center,2));
                    ab = full(X*center');
                    D = bsxfun(@plus,aa,bb') - 2*ab;
                    D(D<0) = 0;
                else
                    aa = full(sum(X.*X,2));
                    D = aa(:,ones(1,k)) + D;
                    D(D<0) = 0;
                end
                D = sqrt(D);
                for j = 1:k
                    sumD(j) = sum(D(label==j,j));
                end
                if sum(sumD) < sum(bestsumD)
                    bestlabel = label;
                    bestcenter = center;
                    bestsumD = sumD;
                    bestD = D;
                end
            end
        case 'cosine'
            while any(label ~= last) && it<maxit
                last = label;
                W=full(X*center');
                [val,label] = max(W,[],2); % assign samples to the nearest centers
                ll = unique(label);
                if length(ll) < k
                    missCluster = 1:k;
                    missCluster(ll) = [];
                    missNum = length(missCluster);
                    [dump,idx] = sort(val);
                    label(idx(1:missNum)) = missCluster;
                end
                E = sparse(1:n,label,1,n,k,n);  % transform label into indicator matrix
                center = full((E*spdiags(1./sum(E,1)',0,k,k))'*X);    % compute center of each cluster
                centernorm = sqrt(sum(center.^2, 2));
                center = center ./ centernorm(:,ones(1,p));
                it=it+1;
            end
            if it<maxit
                bCon = true;
            end
            if isempty(bestlabel)
                bestlabel = label;
                bestcenter = center;
                if reps>1
                    if any(label ~= last)
                        W=full(X*center');
                    end
                    D = 1-W;
                    for j = 1:k
                        sumD(j) = sum(D(label==j,j));
                    end
                    bestsumD = sumD;
                    bestD = D;
                end
            else
                if any(label ~= last)
                    W=full(X*center');
                end
                D = 1-W;
                for j = 1:k
                    sumD(j) = sum(D(label==j,j));
                end
                if sum(sumD) < sum(bestsumD)
                    bestlabel = label;
                    bestcenter = center;
                    bestsumD = sumD;
                    bestD = D;
                end
            end
    end
end

label = bestlabel;
center = bestcenter;
if reps>1
    sumD = bestsumD;
    D = bestD;
elseif nargout > 3
    switch distance
        case 'sqeuclidean'
            if it>=maxit
                aa = full(sum(X.*X,2));
                bb = full(sum(center.*center,2));
                ab = full(X*center');
                D = bsxfun(@plus,aa,bb') - 2*ab;
                D(D<0) = 0;
            else
                aa = full(sum(X.*X,2));
                D = aa(:,ones(1,k)) + D;
                D(D<0) = 0;
            end
            D = sqrt(D);
        case 'cosine'
            if it>=maxit
                W=full(X*center');
            end
            D = 1-W;
    end
    for j = 1:k
        sumD(j) = sum(D(label==j,j));
    end
end
end%%%%%%%%%%%%%%%%%%%%%%%%litekmeans    end




function [eid,emsg,varargout]=getargs(pnames,dflts,varargin)
%GETARGS Process parameter name/value pairs 
%   [EID,EMSG,A,B,...]=GETARGS(PNAMES,DFLTS,'NAME1',VAL1,'NAME2',VAL2,...)
%   accepts a cell array PNAMES of valid parameter names, a cell array
%   DFLTS of default values for the parameters named in PNAMES, and
%   additional parameter name/value pairs.  Returns parameter values A,B,...
%   in the same order as the names in PNAMES.  Outputs corresponding to
%   entries in PNAMES that are not specified in the name/value pairs are
%   set to the corresponding value from DFLTS.  If nargout is equal to
%   length(PNAMES)+1, then unrecognized name/value pairs are an error.  If
%   nargout is equal to length(PNAMES)+2, then all unrecognized name/value
%   pairs are returned in a single cell array following any other outputs.
%
%   EID and EMSG are empty if the arguments are valid.  If an error occurs,
%   EMSG is the text of an error message and EID is the final component
%   of an error message id.  GETARGS does not actually throw any errors,
%   but rather returns EID and EMSG so that the caller may throw the error.
%   Outputs will be partially processed after an error occurs.
%
%   This utility can be used for processing name/value pair arguments.
%
%   Example:
%       pnames = {'color' 'linestyle', 'linewidth'}
%       dflts  = {    'r'         '_'          '1'}
%       varargin = {{'linew' 2 'nonesuch' [1 2 3] 'linestyle' ':'}
%       [eid,emsg,c,ls,lw] = statgetargs(pnames,dflts,varargin{:})    % error
%       [eid,emsg,c,ls,lw,ur] = statgetargs(pnames,dflts,varargin{:}) % ok

% We always create (nparams+2) outputs:
%    one each for emsg and eid
%    nparams varargs for values corresponding to names in pnames
% If they ask for one more (nargout == nparams+3), it's for unrecognized
% names/values

%   Original Copyright 1993-2008 The MathWorks, Inc. 
%   Modified by Deng Cai (dengcai@gmail.com) 2011.11.27




% Initialize some variables
emsg = '';
eid = '';
nparams = length(pnames);
varargout = dflts;
unrecog = {};
nargs = length(varargin);

% Must have name/value pairs
if mod(nargs,2)~=0
    eid = 'WrongNumberArgs';
    emsg = 'Wrong number of arguments.';
else
    % Process name/value pairs
    for j=1:2:nargs
        pname = varargin{j};
        if ~ischar(pname)
            eid = 'BadParamName';
            emsg = 'Parameter name must be text.';
            break;
        end
        i = strcmpi(pname,pnames);
        i = find(i);
        if isempty(i)
            % if they've asked to get back unrecognized names/values, add this
            % one to the list
            if nargout > nparams+2
                unrecog((end+1):(end+2)) = {varargin{j} varargin{j+1}};
                % otherwise, it's an error
            else
                eid = 'BadParamName';
                emsg = sprintf('Invalid parameter name:  %s.',pname);
                break;
            end
        elseif length(i)>1
            eid = 'BadParamName';
            emsg = sprintf('Ambiguous parameter name:  %s.',pname);
            break;
        else
            varargout{i} = varargin{j+1};
        end
    end
end
end

% varargout{nparams+1} = unrecog;

function [Zi,obj] = algo_AZ(X,Y,m,beta) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%algo
% m      : the number of anchors. the size of Z is m*n.
% lambda : the hyper-parameter of regularization term.
% X      : n*di
% \min_{\mathbf{Z}_{i},\mathbf{A}_{i}}\|\mathbf{X}_{i}-\mathbf{Z}_{i}\mathbf{A}_{i}\|_F^2 +\beta\|\mathbf{Z}_{i}\|_F^2,
% s.t. \mathbf{A}_{i}\mathbf{A}_{i}^{\top}=\mathbf{I}_{m},\mathbf{Z}_{i}\geq\mathbf{0},\mathbf{Z}_{i}\mathbf{1}_{m}=\mathbf{1}_{n}.
%% initialize
maxIter = 50 ; % the number of iterations

numview = length(X);
numsample = size(Y,1);
k = length(unique(Y));

M = cell(numview,1);

for i = 1:numview
%     save X X;
   if size(X{i},1)<m
       A{i} = initialize(X{i},m);
       A{i} = A{i}';
   else
        rand('twister',5489);
        [~, A{i}] = litekmeans(X{i},m,'MaxIter', 100,'Replicates',10);
        A{i} = A{i}';
   end
   X{i} = mapstd(X{i}',0,1); % turn into d*n

   M{i} = (A{i}'*X{i}); 
   for ii=1:numsample
       idx = 1:m;
       pp(idx,ii) = EProjSimplex_new(M{i} (idx,ii));           
    end
    Zi{i} = pp;
%      Zi=double(Zi{i});
%      Zi=Zi';
%      Z={};
%      Z={Zi;Z};
%       Z(cellfun(@isempty,A))=[];
%       Zi=Z;
    clear pp;
end
 



flag = 1;
iter = 0;
%%
while flag
    iter = iter + 1;
    
    %% optimize A_i
    for ia = 1:numview
        if size(A{ia},1)<size(A{ia},2)
            A{ia} = X{ia}*Zi{ia}'*pinv(Zi{ia}*Zi{ia}');
        else
            C = X{ia}*Zi{ia}'; 
            C(isnan(C)) = 0;
            [U,~,V] = svd(C,'econ');
            A{ia} = U*V';
        end
    end
    
   %% optimize Z-i            

    for a=1:numview
        M{a} = (A{a}'*X{a})/(1+beta); 
        for ii=1:numsample
            idx = 1:m;
            pp(idx,ii) = EProjSimplex_new(M{a} (idx,ii));           
        end
        Zi{a} = pp;
        clear pp;
    end

    %%
    term1 = 0;
    term2 = 0;
    for iv = 1:numview
        term1 = term1 + norm(X{iv} - A{iv} * Zi{iv},'fro')^2;
        term2 = term2 + norm(Zi{iv},'fro')^2;
    end
    
    obj(iter) = term1+beta*term2;
    
    if (iter>9) && (abs((obj(iter-1)-obj(iter))/(obj(iter-1)))<1e-6 || iter>maxIter || obj(iter) < 1e-10)
        flag = 0;
    end
end

end        %%%%%%%%%%%%%%%%%%%%%%%%%%%algo   end
         
         
    

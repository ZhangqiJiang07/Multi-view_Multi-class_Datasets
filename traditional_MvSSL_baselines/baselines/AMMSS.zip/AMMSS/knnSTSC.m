function [A] = knnSTSC()
end

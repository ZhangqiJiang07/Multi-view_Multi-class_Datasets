function [W] = ammssConstructGraph(X, k)
% X: cell, (num, d_v, V)
% k: number for KNN
V = max(size(X));
options = [];
options.NeighborMode = 'KNN';
options.k = k;
options.WeightMode = 'HeatKernel';


for v=1:V


end
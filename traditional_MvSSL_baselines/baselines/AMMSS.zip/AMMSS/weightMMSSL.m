function [Ypre,out] = weightMMSSL(A, Ll, inPara)

% solve the following problem: i = 1: V
% min_(G,G_i,G_l=Y_l, alpha_i>=0, sum(alpha_i)=1) 
% sum(alpha_i^r * Trace(G_i'L_iG_i)) + lamda*sum(trace((G_0-G_i)'*(G_0-G_i)))
% input: 
%       inY_tr:  the labeled training label matrix, n_tr by C
%       inPara:  the parameters structure
%                inPara.r: the weights distribution scalor
%                inPara.alpha: the initial weight vector 
%                inPara.lambda: the regularization parameter
% output:
%       outAlpha: the learnt Alpha vector
%       outAlphaR: the learnt Alpha^r vector, i.e. the weight vector for
%                  different view
%       outG_0: the learnt common label indicator matrix, continuous
%       outG_b: the learnt common label indicator matrix, discrete
%       outObj: the obj value of the proposed function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ref:
%%% Xiao Cai, Feiping Nie, Weidong Cai, Heng Huang
%%% Heterogeneous Image Features Integration via Multi-modal 
%%% Semi-supervised Learning Model. ICCV 2013: 1737-1744
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameter setting
maxIter = 5;
thresh = 1e-4;
lambda = inPara.lambda;
r = inPara.r;
l = size(Ll, 1);
inY_tr = zeros(l,max(Ll));
for i=1:l
    inY_tr(i,Ll(i))=1;
end 
if(r == 1)
    r = r+eps;
end
V = max(size(A)); % num of view
for v = 1: V
    A{v} = (A{v}+A{v}')/2;
    d = sum(A{v});       
    D = diag(d);
    inL(:,:,v) = D-A{v};
    alpha(v) = 1/V;
end
clear A��
N = size(inL, 1); % num of data point
C = size(inY_tr,2); % num of class
% pre-calculation
tmp = 1/(1-r);
I = eye(N);
% pre-allocation
outG_0 = zeros(N, C); 
obj = zeros(maxIter, 1);
for iter = 1: maxIter
    fprintf('processing iteration %d...\n', iter);
    % given alpha, update G_0
    H = zeros(N,N);
    for v = 1: V
        TT{v} = inv((alpha(v).^r) * inL(:,:,v)+lambda*I);
        H = H + I-lambda*TT{v};
    end           
    H_uu = H((l+1):end, (l+1):end);
    H_ul = H((l+1):end, 1:l);
    G_0_u = (-1)*H_uu\H_ul*inY_tr;
    G_0 = [inY_tr; G_0_u];
        
    % given G_0, update G
    G = zeros(N, C, V);
    for v = 1: V
        G(:,:,v) = lambda * TT{v} * G_0;
    end
    
    % given G_0, update alpha
    for v = 1:V
        g(v) = trace(G(:,:,v)'*inL(:,:,v)*G(:,:,v));
    end
    alpha = ((r*g).^tmp)/(sum(((r*g).^tmp)));
    
    % calculate the objective
    tt = zeros(V, 1);
    for v = 1: V
        tt(v) = trace((G_0 - G(:,:,v))'*(G_0 - G(:,:,v)));
    end
    obj(iter) = sum((alpha.^r).*g) + lambda * sum(tt);
    if(iter > 2)
        obj_diff = (obj(iter-1) - obj(iter))/obj(iter-1);
        if(obj_diff < thresh)
            break;
        end
    end
end
out.Obj = obj(2:iter);
out.lpha = alpha;
out.AlphaR = alpha.^r;
out.G_0 = G_0;
out.G_0_u = G_0_u;
% discretize the label indicator matrix
[max_value,max_ind] = max(G_0_u,[],2);
Ypre = max_ind;
end













